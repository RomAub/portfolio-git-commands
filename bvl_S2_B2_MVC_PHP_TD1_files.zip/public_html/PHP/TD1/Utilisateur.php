<?php
class Utilisateur {
    private $login;
    private $nom;
    private $prenom;

    public function __construct($data) {
        foreach ($data as $cle => $valeur) {
            $this->$cle = $valeur;
        }
    }

    public function get($nom_attribut) {
        return $this->$nom_attribut;
    }

    public function set($nom_attribut, $valeur) {
        $this->$nom_attribut = $valeur;
    }
}
?>


