/***********************************************************************
 * Module:  Auteur.java
 * Author:  admin
 * Purpose: Defines the Class Auteur
 ***********************************************************************/

import java.util.*;

/** @pdOid 03223d05-1b81-4c2f-be61-d2b0ee9b78de */
public class Auteur {
   /** @pdOid b40e7aaa-f03f-42d3-ad4d-8b2de0f4eb3c */
   private java.lang.String nom;
   /** @pdOid 7c1cc38e-23b8-407f-829f-979571875be5 */
   private java.lang.String prenom;
   /** @pdOid 2a87fcbd-6889-4356-8dd8-34e90f598265 */
   private Date dateDeNaissance;
   /** @pdOid 01221dae-194d-4c32-a257-1a3d4e9b0578 */
   private java.lang.String descriptionAuteur;
   
   /** @pdRoleInfo[ migr=no] name=Livre assc=auteurLivre mult=1..* side=A */
   public Livre[] livreEcrit;
   
   /** @pdOid c2668580-5303-40db-9bb1-4778a66b0f16 */
   public java.lang.String getNom() {
      return nom;
   }
   
   /** @param newNom
    * @pdOid 80e96b7f-1c52-474f-a4d0-fdc87513fb73 */
   public void setNom(java.lang.String newNom) {
      nom = newNom;
   }
   
   /** @pdOid 737c225b-c0b9-4c6d-8b4d-72544f2823c3 */
   public java.lang.String getPrenom() {
      return prenom;
   }
   
   /** @param newPrenom
    * @pdOid 7edb66e3-eaad-47de-9dba-54b5fe496867 */
   public void setPrenom(java.lang.String newPrenom) {
      prenom = newPrenom;
   }
   
   /** @pdOid 10c8d6e8-a599-4663-8806-d90014233151 */
   public Date getDateDeNaissance() {
      return dateDeNaissance;
   }
   
   /** @param newDateDeNaissance
    * @pdOid 7d92f9cb-3f3f-42df-ace4-252f9d4cc148 */
   public void setDateDeNaissance(Date newDateDeNaissance) {
      dateDeNaissance = newDateDeNaissance;
   }
   
   /** @pdOid 5e6a3923-27e2-470e-8e7a-6ef629ac1219 */
   public java.lang.String getDescriptionAuteur() {
      return descriptionAuteur;
   }
   
   /** @param newDescriptionAuteur
    * @pdOid 5ccc5a1c-f500-4422-8486-ee596b658ea0 */
   public void setDescriptionAuteur(java.lang.String newDescriptionAuteur) {
      descriptionAuteur = newDescriptionAuteur;
   }

}