/***********************************************************************
 * Module:  Livre.java
 * Author:  admin
 * Purpose: Defines the Class Livre
 ***********************************************************************/

import java.util.*;

/** @pdOid 873fc936-3268-4c70-8734-fa8469d8502e */
public class Livre {
   /** @pdOid f426dbaf-614e-4bd2-89ba-250bb4c82327 */
   private int isbn;
   /** @pdOid c8da686a-e125-48b8-b431-88bad7edf412 */
   private java.lang.String titre;
   /** @pdOid ecf00c1c-74d2-4bc0-883a-55f56690afac */
   private java.lang.String auteur;
   /** @pdOid 0b3b525f-304c-470a-83eb-18e246849530 */
   private Float prix;
   /** @pdOid 2a34282c-6158-4532-b89c-47eeed443adf */
   private java.lang.String description;
   /** @pdOid 679481e8-6d69-4295-9151-5f5c2e4a1947 */
   private java.lang.String categorie;
   
   /** @pdRoleInfo migr=no name=Auteur assc=auteurLivre mult=1..* */
   public Auteur[] auteurs;
   /** @pdRoleInfo[ migr=no] name=Adherent assc=empreint mult=0..1 side=A */
   public Adherent empreinteur;
   
   /** @pdOid 4a14735a-3a79-4fea-a226-742d6b681eb4 */
   public int getIsbn() {
      return isbn;
   }
   
   /** @param newIsbn
    * @pdOid 1a8a6a67-7ad9-4fb8-bb71-306564525ac9 */
   public void setIsbn(int newIsbn) {
      isbn = newIsbn;
   }
   
   /** @pdOid 268e6dca-792d-4fbf-bdcc-ea195eb62f85 */
   public java.lang.String getTitre() {
      return titre;
   }
   
   /** @param newTitre
    * @pdOid 2d3fb608-b61b-48ce-a212-6b64df1f3a4c */
   public void setTitre(java.lang.String newTitre) {
      titre = newTitre;
   }
   
   /** @pdOid 1e5c5720-b443-4b86-abf3-08137be19b7b */
   public java.lang.String getAuteur() {
      return auteur;
   }
   
   /** @param newAuteur
    * @pdOid bae529e8-c54a-4b13-ac39-f848e2a00a7a */
   public void setAuteur(java.lang.String newAuteur) {
      auteur = newAuteur;
   }
   
   /** @pdOid 661db317-5a2a-4462-9faa-c6fa7a001ce5 */
   public Float getPrix() {
      return prix;
   }
   
   /** @param newPrix
    * @pdOid ceaed8da-206f-412f-8ebc-dd9d8c2d86d7 */
   public void setPrix(Float newPrix) {
      prix = newPrix;
   }
   
   /** @pdOid be59fc72-0093-407a-be55-43a0bdaede30 */
   public java.lang.String getDescription() {
      return description;
   }
   
   /** @param newDescription
    * @pdOid d1f64263-6452-48a2-b076-148bdba3d11f */
   public void setDescription(java.lang.String newDescription) {
      description = newDescription;
   }
   
   /** @pdOid a21f3936-61b4-4281-ae7f-4d1832cdab94 */
   public java.lang.String getCategorie() {
      return categorie;
   }
   
   /** @param newCategorie
    * @pdOid b406b1d6-f677-46d9-8a5b-f7ccca2eb92f */
   public void setCategorie(java.lang.String newCategorie) {
      categorie = newCategorie;
   }

}