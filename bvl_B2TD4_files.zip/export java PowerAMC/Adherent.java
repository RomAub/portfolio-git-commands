/***********************************************************************
 * Module:  Adherent.java
 * Author:  admin
 * Purpose: Defines the Class Adherent
 ***********************************************************************/

import java.util.*;

/** @pdOid 5504bb76-c2ef-4c06-8898-29f7dbf718c7 */
public class Adherent {
   /** @pdOid 0c00efb2-9b1d-45a4-b1df-1169bc2d12f3 */
   private java.lang.String nom;
   /** @pdOid 16a60efe-0dd9-4d56-b17e-4ab386b75210 */
   private java.lang.String prenom;
   /** @pdOid 0640f1f4-5d4d-4c05-8712-b29669d0b5e9 */
   private int tel;
   /** @pdOid 31022524-6d7c-441b-b970-7148c08d384b */
   private java.lang.String adresse;
   /** @pdOid 31ec36a1-6747-4d44-9619-541181bed7f7 */
   private java.lang.String mail;
   
   /** @pdRoleInfo migr=no name=Livre assc=empreint mult=0..5 */
   public Livre[] livreEmpreintes;
   
   /** @pdOid b5902f94-9c4a-4b0f-87fe-43281d882fb9 */
   public java.lang.String getNom() {
      return nom;
   }
   
   /** @param newNom
    * @pdOid b2c217da-d7f7-4990-89f7-a6568c9760e1 */
   public void setNom(java.lang.String newNom) {
      nom = newNom;
   }
   
   /** @pdOid 43518a41-172b-4a5f-9a05-1540739d85c2 */
   public java.lang.String getPrenom() {
      return prenom;
   }
   
   /** @param newPrenom
    * @pdOid bc321dcb-55af-492c-841c-be2b70acb096 */
   public void setPrenom(java.lang.String newPrenom) {
      prenom = newPrenom;
   }
   
   /** @pdOid fc142352-5f6a-4b3f-a639-c68fe2e06d1c */
   public int getTel() {
      return tel;
   }
   
   /** @param newTel
    * @pdOid 43316bfe-e924-4805-a1d9-40c576020e92 */
   public void setTel(int newTel) {
      tel = newTel;
   }
   
   /** @pdOid 301b4b7a-b926-4219-bc2e-0d91dbc0d604 */
   public java.lang.String getAdresse() {
      return adresse;
   }
   
   /** @param newAdresse
    * @pdOid 3b772f98-5351-4eb7-9e45-f6942d37531d */
   public void setAdresse(java.lang.String newAdresse) {
      adresse = newAdresse;
   }
   
   /** @pdOid 0e54f031-9b7a-4413-88f0-ae37f662f363 */
   public java.lang.String getMail() {
      return mail;
   }
   
   /** @param newMail
    * @pdOid 749849ca-f32f-42a5-8f14-60600d4189f1 */
   public void setMail(java.lang.String newMail) {
      mail = newMail;
   }

}