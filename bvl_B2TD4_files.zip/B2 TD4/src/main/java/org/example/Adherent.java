package org.example;

import java.util.*;

public class Adherent {
   private String nom;
   private String prenom;
   private int tel;
   private String adresse;
   private String mail;

   public Livre[] livreEmpreintes;

   public String getNom() {
      return nom;
   }
   public void setNom(String newNom) {
      nom = newNom;
   }

   public String getPrenom() {
      return prenom;
   }
   public void setPrenom(String newPrenom) {
      prenom = newPrenom;
   }

   public int getTel() {
      return tel;
   }
   public void setTel(int newTel) {
      tel = newTel;
   }

   public String getAdresse() {
      return adresse;
   }
   public void setAdresse(String newAdresse) {
      adresse = newAdresse;
   }

   public String getMail() {
      return mail;
   }
   public void setMail(String newMail) {
      mail = newMail;
   }

}