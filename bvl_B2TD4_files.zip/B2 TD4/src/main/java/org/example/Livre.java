package org.example;

import java.util.*;

public class Livre {
   private long isbn;
   private String titre;
   private String auteur;
   private Float prix;
   private String description;
   private String categorie;

   public Auteur[] auteurs;
   public Adherent empreinteur;

   public long getIsbn() {
      return isbn;
   }
   public void setIsbn(long newIsbn) {
      isbn = newIsbn;
   }

   public String getTitre() {
      return titre;
   }
   public void setTitre(String newTitre) {
      titre = newTitre;
   }

   public String getAuteur() {
      return auteur;
   }
   public void setAuteur(String newAuteur) {
      auteur = newAuteur;
   }

   public Float getPrix() {
      return prix;
   }
   public void setPrix(Float newPrix) {
      prix = newPrix;
   }

   public String getDescription() {
      return description;
   }
   public void setDescription(String newDescription) {
      description = newDescription;
   }

   public String getCategorie() {
      return categorie;
   }
   public void setCategorie(String newCategorie) {
      categorie = newCategorie;
   }

}