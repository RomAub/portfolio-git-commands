package org.example;

import java.util.*;

public class Auteur {
   private String nom;
   private String prenom;
   private Date dateDeNaissance;
   private String descriptionAuteur;

   public Livre[] livreEcrit;

   public String getNom() {
      return nom;
   }
   public void setNom(String newNom) {
      nom = newNom;
   }

   public String getPrenom() {
      return prenom;
   }
   public void setPrenom(String newPrenom) {
      prenom = newPrenom;
   }

   public Date getDateDeNaissance() {
      return dateDeNaissance;
   }
   public void setDateDeNaissance(Date newDateDeNaissance) {
      dateDeNaissance = newDateDeNaissance;
   }

   public String getDescriptionAuteur() {
      return descriptionAuteur;
   }
   public void setDescriptionAuteur(String newDescriptionAuteur) {
      descriptionAuteur = newDescriptionAuteur;
   }

}