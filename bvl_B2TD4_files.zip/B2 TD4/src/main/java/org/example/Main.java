package org.example;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Main {
    public static void main(String[] args) {

        ArrayList<Livre> catalogue = new ArrayList<>();
        ArrayList<Adherent> bibliotheque = new ArrayList<>();

        Auteur a1 = new Auteur();
        a1.setNom("Camus");
        a1.setPrenom("Albert");
        a1.setDateDeNaissance(date("07/11/1913"));
        a1.setDescriptionAuteur("Albert Camus, né le 7 novembre 1913... écrivain, philosophe.");
        a1.livreEcrit = new Livre[999]; // Je suis obliger d'utiliser les tableaux car les .java on été généré avec PowerAMC

        Auteur a2 = new Auteur();
        a2.setNom("Flaubert");
        a2.setPrenom("Gustave");
        a2.setDateDeNaissance(date("12/12/1821"));
        a2.setDescriptionAuteur("Gustave Flaubert est un écrivain français né à Rouen...");
        a2.livreEcrit = new Livre[999]; // Je suis obliger d'utiliser les tableaux car les .java on été généré avec PowerAMC

        Auteur a3 = new Auteur();
        a3.setNom("Burd");
        a3.setPrenom("Barry");
        a3.setDescriptionAuteur("Professor at Drew University...");
        a3.livreEcrit = new Livre[999]; // Je suis obliger d'utiliser les tableaux car les .java on été généré avec PowerAMC

        Livre l1 = new Livre();
        l1.setIsbn(8573823224L);
        l1.setTitre("L'étranger");
        l1.setPrix(20.0f);
        l1.setDescription("L’Étranger est le premier roman d’Albert Camus...");
        l1.setCategorie("Roman");
        l1.setAuteur("Albert Camus");
        l1.auteurs = new Auteur[]{a1};
        catalogue.add(l1);

        Livre l2 = new Livre();
        l2.setIsbn(7495948500L);
        l2.setTitre("Madame Bovary");
        l2.setPrix(19.5f);
        l2.setDescription("Madame Bovary: Mœurs de province...");
        l2.setCategorie("Roman");
        l2.setAuteur("Gustave Flaubert");
        l2.auteurs = new Auteur[]{a2};
        catalogue.add(l2);

        Livre l3 = new Livre();
        l3.setIsbn(9782844273L);
        l3.setTitre("Java pour les nuls");
        l3.setPrix(50.0f);
        l3.setDescription("Grâce à ce livre, vous allez rapidement écrire...");
        l3.setCategorie("Education");
        l3.setAuteur("Barry Burd");
        l3.auteurs = new Auteur[]{a3};
        catalogue.add(l3);

        Adherent ad1 = new Adherent();
        ad1.setNom("ABDALLA");
        ad1.setPrenom("Abdelrhman");
        ad1.setTel(123456789);
        ad1.setAdresse("8 rue de paris, 92 Courbevoie");
        ad1.setMail("Abdelrhman@gmail.com");
        ad1.livreEmpreintes = new Livre[5];
        bibliotheque.add(ad1);

        Adherent ad2 = new Adherent();
        ad2.setNom("AGLAS");
        ad2.setPrenom("Lionel");
        ad2.setTel(987654321);
        ad2.setAdresse("8 rue de Courbevoie, 75000 Paris");
        ad2.setMail("Lionel@gmail.com");
        ad2.livreEmpreintes = new Livre[5];
        bibliotheque.add(ad2);

        Adherent ad3 = new Adherent();
        ad3.setNom("ALLAM");
        ad3.setPrenom("Ali");
        ad3.setMail("Ali@gmail.com");
        ad3.livreEmpreintes = new Livre[5];
        bibliotheque.add(ad3);

        // Q4
        for (Adherent ad : bibliotheque) {
            System.out.println("- " + ad.getNom() + " " + ad.getPrenom());
        }

        emprunter(ad1, l1);

        System.out.println("Lionel essaie de voler le livre d'Abdalla...");
        emprunter(ad2, l1);


        emprunter(ad2, l2);

        if (l1.empreinteur != null) {
            System.out.println("Le livre " + l1.getTitre() + " est actuellement chez : " + l1.empreinteur.getNom());
        }

        for (Livre l : catalogue) {
            System.out.println("------------------------------------------------");
            System.out.println("LIVRE     : " + l.getTitre());
            System.out.println("AUTEUR    : " + l.auteurs[0].getNom());
            System.out.println("CATÉGORIE : " + l.getCategorie());

            if (l.empreinteur != null) {
                System.out.println("ÉTAT : EMPRUNTÉ par " + l.empreinteur.getNom());
            } else {
                System.out.println("ÉTAT : DISPONIBLE");
            }
        }
    }

    // Code pour écrire date plus facilement
    public static Date date(String s) {
        try {
            return new SimpleDateFormat("dd/MM/yyyy").parse(s);
        } catch (Exception e) {
            return null;
        }
    }

    public static void emprunter(Adherent ad, Livre l) {
        if (l.empreinteur != null) {
            System.out.println("IMPOSSIBLE : Le livre '" + l.getTitre() + "' est déjà chez " + l.empreinteur.getNom());
            return;
        }

        boolean aDeLaPlace = false;
        for (int i = 0; i < ad.livreEmpreintes.length; i++) {
            if (ad.livreEmpreintes[i] == null) {
                ad.livreEmpreintes[i] = l;
                l.empreinteur = ad;
                System.out.println(ad.getNom() + " a réussi à emprunter : " + l.getTitre());
                aDeLaPlace = true;
                break;
            }
        }

        if (!aDeLaPlace) {
            System.out.println("ERREUR : " + ad.getNom() + " a déjà 5 livres !");
        }
    }
}