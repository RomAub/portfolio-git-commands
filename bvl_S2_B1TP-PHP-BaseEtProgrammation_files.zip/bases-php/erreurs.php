<?php require 'variables.php'; ?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8" />
    <title>Ma page de présentation</title>
</head>
<body>
    <h1>Ma présentation</h1>
    <p>
        <?php
        echo "Bonjour, je m'appelle $prenom et je suis en $classe.<br>";
        // Un commentaire
        echo "Je connais $nbLangages langages de programmation";
        ?>
    </p>
</body>
</html>

