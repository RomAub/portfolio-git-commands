<?php
$nom = "Michel";
$age = 50;
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>La page de <?php echo $nom; ?></title>
</head>
<body>
    <h1>Bienvenue !</h1>
    <?php
    echo "Bonjour, je m'appelle ", $nom, " et j'ai ", $age, " ans.";
    ?>
</body>
</html>