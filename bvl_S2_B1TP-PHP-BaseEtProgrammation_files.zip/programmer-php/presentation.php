<!doctype html>
<html>
    <?php
    $prenom = "Carlos";
	$classe = "BTS SIO 1";
	$langages = ["C#", "PHP", "HTML", "CSS", "JavaScript"];
	$nbLangages = count($langages)
    ?>
	
<head>
    <meta charset="utf-8" />
    <title><?php echo "La page de $prenom - (Exercice 2)" ?></title>
</head>
<body>
	<h1>Ma présentation</h1>
    <p>
        <?php
		echo "Bonjour, je m'appelle $prenom et je suis en $classe. <br><br>";
		
		if ($nbLangages < 3) {
			$status = "débutant";
		} elseif ($nbLangages < 5) {
			$status = "débrouillé";
		} else {
			$status = "aguerri";
		}
		
		echo "Je suis un programmeur $status. Je connais $nbLangages language(s) de programmation :";
        ?>
    </p>
	<ul>
		<?php
        foreach ($langages as $langage) {
            echo "$langage";
        }
        ?>
	</ul>
</body>
</html>
