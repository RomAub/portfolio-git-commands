<!doctype html>
<html>
<head>
    <meta charset="utf-8" />
    <title>Exercice 1</title>
</head>
<body>
    <?php
    $chiffre = 12;
    ?>
	<h1><?php echo "Table de $chiffre" ?></h1>
    <p>
        <?php
		for ($i = 0; $i <= 10; $i++) {
			$resultat = $chiffre * $i;
			echo "$chiffre * $i = $resultat <br>";
		}
        ?>
    </p>
</body>
</html>