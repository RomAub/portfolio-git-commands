<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Service sélectionné</title>
</head>
<body>
	<?php
	if (isset($_POST['service'])) {
		$service = $_POST['service'];
		echo "<p>Le code du service choisi est $service</p>";
		} else {
		echo "<p>Erreur : aucun service</p>";
	}
	?>
</body>
</html>
