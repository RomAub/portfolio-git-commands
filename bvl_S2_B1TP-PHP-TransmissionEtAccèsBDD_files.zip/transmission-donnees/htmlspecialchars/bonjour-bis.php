<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Bonjour Bis</title>
</head>
<body>
    <?php
    if (isset($_POST['prenom'])) {
        $prenom = htmlspecialchars($_POST['prenom']);
        $salutation = isset($_POST['familier']) ? "Salut" : "Bonjour,";
        $civilite = isset($_POST['civilite']) ? htmlspecialchars($_POST['civilite']) : "";
        echo "<h2>$salutation $civilite $prenom !</h2><hr>";
    }
    ?>
    <form action="" method="post">
        <p><label>Entrez votre prénom : <input type="text" name="prenom" required></label></p>
        <p><label>Cochez pour un bonjour plus familier : <input type="checkbox" name="familier"></label></p>
        <p>
            <label><input type="radio" name="civilite" value="Mademoiselle"> Mademoiselle</label><br>
            <label><input type="radio" name="civilite" value="Madame"> Madame</label><br>
            <label><input type="radio" name="civilite" value="Monsieur" checked> Monsieur</label>
        </p>
        <p><input type="submit" value="Dire bonjour"></p>
    </form>
</body>
</html>
