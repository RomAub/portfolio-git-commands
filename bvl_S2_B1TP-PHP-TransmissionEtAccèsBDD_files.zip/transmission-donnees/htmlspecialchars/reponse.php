<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Réponse</title>
</head>
<body>
    <?php
    if (isset($_POST['prenom'])) {
        $prenom = htmlspecialchars($_POST['prenom']);
        $salutation = isset($_POST['familier']) ? "Salut" : "Bonjour,";
        $civilite = isset($_POST['civilite']) ? htmlspecialchars($_POST['civilite']) : "";
        
        echo "<p>$salutation $civilite $prenom !</p>";
    } else {
        echo "<p>Erreur : prénom manquant.</p>";
    }
    ?>
</body>
</html>


