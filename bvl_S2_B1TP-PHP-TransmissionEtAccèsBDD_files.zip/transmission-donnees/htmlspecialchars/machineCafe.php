<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Machine à café</title>
</head>
<body>
	<h1>Votre boisson</h1>
    <form action="" method="post">
        <p><label>Nom : <input type="text" name="nom" required></label></p>
		<p><label>Prénom : <input type="text" name="prenom" required></label></p>
		<select name="boisson" id="boisson">
			<option value="Café">Café</option>
			<option value="Thé">Thé</option>
			<option value="Chocolat">Chocolat</option>
			<option value="Café crème">Café crème</option>
		</select>
        <p>
            <label><input type="radio" name="sucre" value="oui" checked> Sucre</label><br>
            <label><input type="radio" name="sucre" value="non"> Sans sucre</label><br>
        </p>
        <p>
		<input type="submit" value="Valider">
		<input type="reset" value="Annuler">
		</p>
    </form>
	
	<?php
    if (isset($_POST['nom']) && isset($_POST['prenom'])) {
		$nom = htmlspecialchars($_POST['nom']);
        $prenom = htmlspecialchars($_POST['prenom']);
        $boisson = htmlspecialchars($_POST['boisson']);
        $sucre = isset($_POST['sucre']) && htmlspecialchars($_POST['sucre']) == "oui" ? "Oui" : "Non";
        echo "<p><hr>Bonjour $nom $prenom<br>
		Votre choix : $boisson<br>
		Sucre : $sucre</p>";
    }
    ?>
</body>
</html>
