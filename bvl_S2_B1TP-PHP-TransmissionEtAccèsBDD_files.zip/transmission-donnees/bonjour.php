<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Bonjour</title>
</head>
<body>
    <form action="reponse.php" method="post">
        <p>
            <label for="prenom">Entrez votre prénom :</label>
            <input type="text" name="prenom" id="prenom" required>
        </p>
		<p>
            <label for="familier">Cochez pour un bonjour plus familier :</label>
            <input type="checkbox" name="familier" id="familier">
        </p>
		<p>
            <input type="radio" name="civilite" value="Mademoiselle" id="mademoiselle"> 
            <label for="mademoiselle">Mademoiselle</label><br>
            
            <input type="radio" name="civilite" value="Madame" id="madame"> 
            <label for="madame">Madame</label><br>
            
            <input type="radio" name="civilite" value="Monsieur" id="monsieur" checked> 
            <label for="monsieur">Monsieur</label>
        </p>
        <p>
            <input type="submit" value="Dire bonjour">
        </p>
    </form>
</body>
</html>

