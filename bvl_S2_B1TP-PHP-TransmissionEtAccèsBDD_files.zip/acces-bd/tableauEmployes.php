<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Tableau des employés</title>
</head>
<body>
    <h1>Tableau des employés</h1>
    <table border="1">
        <tr>
            <th>Matricule</th>
            <th>Nom</th>
            <th>Prénom</th>
        </tr>
        <?php
        require 'fonctions.php';
        $bdd = getBdd();

        $requete = $bdd->query('SELECT Matricule, NomEmpl, PrenomEmpl FROM employe');
        $employes = $requete->fetchAll();

        foreach ($employes as $employe) {
            $matricule = escape($employe['Matricule']);
            $nom = escape($employe['NomEmpl']);
            $prenom = escape($employe['PrenomEmpl']);
            echo "<tr>";
            echo "<td>$matricule</td>";
            echo "<td>$nom</td>";
            echo "<td>$prenom</td>";
            echo "</tr>";
        }
        ?>
    </table>
    <?php
    $total = count($employes);
    echo "<p>Total : $total employé(s)</p>";
    ?>
</body>
</html>
