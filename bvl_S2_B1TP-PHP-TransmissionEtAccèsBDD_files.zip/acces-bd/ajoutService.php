<?php
require 'fonctions.php';
$bdd = getBdd();
$message = "";
if (isset($_POST['code']) && isset($_POST['designation'])) {
    $codeInsert = $_POST['code'];
    $desiInsert = $_POST['designation'];
    if (!empty($codeInsert) && !empty($desiInsert)) {
        try {
            $reqInsert = $bdd->prepare('INSERT INTO service (CodeServ, DesiServ) VALUES (?, ?)');
            $reqInsert->execute([$codeInsert, $desiInsert]);
            $message = "<p>L'ajout a réussi !</p>";
        } catch (Exception $e) {
            $message = "<p>Erreur lors de l'ajout : Le code service existe peut-être déjà.</p>";
        }
    } else {
        $message = "<p>Veuillez remplir tous les champs.</p>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Ajout d'un service</title>
</head>
<body>
    <h1>Liste des services</h1>
    <table border="1">
        <tr>
            <th>Code</th>
            <th>Désignation</th>
        </tr>
        <?php
        $reqSelect = $bdd->query('SELECT CodeServ, DesiServ FROM service');
        $services = $reqSelect->fetchAll();
        foreach ($services as $service) {
            $codeAffichage = escape($service['CodeServ']);
            $desiAffichage = escape($service['DesiServ']);
            echo "<tr>";
            echo "<td>$codeAffichage</td>";
            echo "<td>$desiAffichage</td>";
            echo "</tr>";
        }
        ?>
    </table>
    <h1>Ajout d'un service</h1>
    <form action="" method="post">
        <p>
            <label for="code">Code :</label>
            <input type="text" name="code" id="code" maxlength="3" required>
        </p>
        <p>
            <label for="designation">Désignation :</label>
            <input type="text" name="designation" id="designation" required>
        </p>
        <p>
            <input type="submit" value="Ajouter le service">
        </p>
    </form>

    <?php 
    echo $message; 
    ?>
</body>
</html>