<?php
function getBdd() {
    try {
        $bdd = new PDO('mysql:host=localhost;dbname=personnel;charset=utf8', 'personnel_util', 'secret');
        $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $bdd;
    } catch (Exception $e) {
        die('Erreur de connexion : ' . $e->getMessage());
    }
}
function escape($valeur) {
    return htmlspecialchars($valeur, ENT_QUOTES, 'UTF-8');
}
?>

