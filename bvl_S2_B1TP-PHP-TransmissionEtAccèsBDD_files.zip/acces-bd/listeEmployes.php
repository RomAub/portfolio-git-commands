<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Liste des employés</title>
</head>
<body>
    <h1>Liste des employés</h1>
    <ul>
    <?php
    require 'fonctions.php';
    $bdd = getBdd();

    $requete = $bdd->query('SELECT NomEmpl, PrenomEmpl FROM employe');
    $employes = $requete->fetchAll();

    foreach ($employes as $employe) {
        $nom = escape($employe['NomEmpl']);
        $prenom = escape($employe['PrenomEmpl']);
        
        echo "<li>$nom $prenom</li>";
    }
    ?>
    </ul>
    <?php
    $total = count($employes);
    echo "<p>Total : $total employé(s)</p>";
    ?>
</body>
</html>

