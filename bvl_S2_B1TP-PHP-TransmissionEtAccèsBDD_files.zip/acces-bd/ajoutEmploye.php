<?php
require 'fonctions.php';
$bdd = getBdd();
$message = "";
if (isset($_POST['matricule'], $_POST['nom'], $_POST['prenom'], $_POST['service'])) {
    $matricule = $_POST['matricule'];
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $service = $_POST['service'];
    $cadre = isset($_POST['cadre']) ? 'o' : 'n';
    if (!empty($matricule) && !empty($nom) && !empty($prenom) && !empty($service)) {
        try {
            $reqInsert = $bdd->prepare('INSERT INTO employe (Matricule, NomEmpl, PrenomEmpl, CodeCadre, ServEmpl) VALUES (?, ?, ?, ?, ?)');
            $reqInsert->execute([$matricule, $nom, $prenom, $cadre, $service]);
            $message = "<p>L'ajout a réussi !</p>";
        } catch (Exception $e) {
            $message = "<p>Erreur lors de l'ajout : Vérifiez que le matricule n'existe pas déjà.</p>";
        }
    } else {
        $message = "<p>Veuillez remplir tous les champs obligatoires.</p>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Ajout d'un employé</title>
</head>
<body>
    <h1>Ajout d'un employé</h1>
    <form action="" method="post">
        <p>
            <label for="matricule">Matricule :</label>
            <input type="text" name="matricule" id="matricule" maxlength="4" required>
        </p>
        <p>
            <label for="nom">Nom :</label>
            <input type="text" name="nom" id="nom" maxlength="25" required>
        </p>
        <p>
            <label for="prenom">Prénom :</label>
            <input type="text" name="prenom" id="prenom" maxlength="20" required>
        </p>
        <p>
            <label for="cadre">Cadre ?</label>
            <input type="checkbox" name="cadre" id="cadre">
        </p>
        <p>
            <label for="service">Service :</label>
            <select name="service" id="service" required>
                <?php
                $reqServices = $bdd->query('SELECT CodeServ, DesiServ FROM service');
                $services = $reqServices->fetchAll();
                foreach ($services as $srv) {
                    $codeSrv = escape($srv['CodeServ']);
                    $desiSrv = escape($srv['DesiServ']);
                    echo "<option value=\"$codeSrv\">$desiSrv</option>";
                }
                ?>
            </select>
        </p>
        <p>
            <input type="submit" value="Ajouter l'employé">
        </p>
    </form>

    <?php 
    echo $message; 
    ?>
</body>
</html>
