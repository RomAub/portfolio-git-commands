<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Sélection du service</title>
</head>
<body>
    <h1>Choix d'un service</h1>
    <form action="employesService.php" method="post">
        <label for="service">Service :</label>
        <select name="service" id="service">
            <?php
            require 'fonctions.php';
            $bdd = getBdd();
            $requete = $bdd->query('SELECT CodeServ, DesiServ FROM service');
            $services = $requete->fetchAll();
            foreach ($services as $service) {
                $code = escape($service['CodeServ']);
                $designation = escape($service['DesiServ']);
                echo "<option value=\"$code\">$designation</option>";
            }
            ?>
        </select>
        <br><br>
        <input type="submit" value="Afficher les employés">
    </form>
</body>
</html>

