<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Liste des employés du service</title>
</head>
<body>
    <?php
    require 'fonctions.php';
    if (isset($_POST['service'])) {
        $bdd = getBdd();
        $codeServiceChoisi = $_POST['service'];
        $reqTitre = $bdd->prepare('SELECT DesiServ FROM service WHERE CodeServ = ?');
        $reqTitre->execute([$codeServiceChoisi]);
        $serviceInfo = $reqTitre->fetch();
        if ($serviceInfo) {
            $nomDuService = escape($serviceInfo['DesiServ']);
            echo "<h1>Liste des employés du service $nomDuService</h1>";
            $reqEmployes = $bdd->prepare('SELECT Matricule, NomEmpl, PrenomEmpl FROM employe WHERE ServEmpl = ?');
            $reqEmployes->execute([$codeServiceChoisi]);
            $employes = $reqEmployes->fetchAll();
            echo "<table border='1'>";
            echo "<tr><th>Matricule</th><th>Nom</th><th>Prénom</th></tr>";
            foreach ($employes as $employe) {
                $matricule = escape($employe['Matricule']);
                $nom = escape($employe['NomEmpl']);
                $prenom = escape($employe['PrenomEmpl']);
                echo "<tr>";
                echo "<td>$matricule</td>";
                echo "<td>$nom</td>";
                echo "<td>$prenom</td>";
                echo "</tr>";
            }
            echo "</table>";

        } else {
            echo "<p>Erreur : Service introuvable en base de données.</p>";
        }
    } else {
        echo "<p>Accès refusé : vous devez passer par le formulaire de sélection.</p>";
    }
    ?>
</body>
</html>