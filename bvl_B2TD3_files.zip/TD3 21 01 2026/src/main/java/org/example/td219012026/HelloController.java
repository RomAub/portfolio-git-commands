package org.example.td219012026;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import java.util.ArrayList;

public class HelloController {

    @FXML private TextField tfISBN;
    @FXML private TextField tfTitre;
    @FXML private TextField tfPrix;
    @FXML private Label lblCompteur;
    @FXML private TextField tfAuteur;

    //exo 5
    private ArrayList<Livre> al = new ArrayList<Livre>();
    private ArrayList test = new ArrayList<>();

    @FXML
    public void initialize() {

        String url = "jdbc:mysql://localhost:3306/slam_td2";
        String login = "root";
        String passwd = "";

        java.sql.Connection cn = null;
        java.sql.Statement st = null;
        java.sql.ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            cn = java.sql.DriverManager.getConnection(url, login, passwd);

            st = cn.createStatement();

            String sql = "SELECT * FROM Livre";
            rs = st.executeQuery(sql);

            while (rs.next()) {
                String isbn = rs.getString("ISBN");
                String titre = rs.getString("titre");
                String auteur = rs.getString("auteur");
                float prix = rs.getFloat("prix");

                al.add(new Livre(isbn, titre, auteur, prix));
            }

        } catch (java.sql.SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                if (cn != null) cn.close();
                if (st != null) st.close();
                if (rs != null) rs.close();
            } catch (java.sql.SQLException e) {
                e.printStackTrace();
            }
        }
        for (Livre l : al) {
            l.Afficher();
            System.out.println();
        }
        lblCompteur.setText("Nombre de livre : " + al.size());
    }

    //exo 7
    @FXML
    protected void onAjouter() {
        String isbn = tfISBN.getText();
        String titre = tfTitre.getText();
        String auteur = tfAuteur.getText();
        float prix = 0;
        try {
            prix = Float.parseFloat(tfPrix.getText());
        } catch (Exception e) {
            System.out.println("Prix incorrect, mis à 0");
        }
        String url = "jdbc:mysql://localhost:3306/slam_td2";
        String login = "root";
        String passwd = "";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            java.sql.Connection cn = java.sql.DriverManager.getConnection(url, login, passwd);
            java.sql.Statement st = cn.createStatement();
            String checkSql = "SELECT * FROM Livre WHERE ISBN = '" + isbn + "'";
            java.sql.ResultSet rs = st.executeQuery(checkSql);
            if (rs.next()) {
                System.out.println("Livre existant trouvé : Mise à jour...");
                String updateSql = "UPDATE Livre SET titre = '" + titre + "', prix = " + prix + " WHERE ISBN = '" + isbn + "'";
                st.executeUpdate(updateSql);
                for (Livre l : al) {
                    if (l.getISBN().equals(isbn)) {
                        l.setTitre(titre);
                        l.setPrix(prix);
                        break;
                    }
                }

            } else {
                System.out.println("Nouveau livre !");
                Livre nouveau = new Livre(isbn, titre, auteur, prix, st);
                al.add(nouveau);
            }
            cn.close();
            st.close();
            rs.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        lblCompteur.setText("Nombre de livre : " + al.size());
        tfISBN.clear();
        tfTitre.clear();
        tfPrix.clear();
        tfAuteur.clear();
    }

    //exo 7
    @FXML
    protected void onRechercher() {
        String recherche = tfISBN.getText();
        boolean trouve = false;

        for (Livre l : al) {
            if (l.getISBN().equals(recherche)) {
                tfTitre.setText(l.getTitre());
                tfPrix.setText(String.valueOf(l.getPrix()));
                tfAuteur.setText(l.getAuteur());
                trouve = true;
                break;
            }
        }

        if (!trouve) {
            tfTitre.setText("ERREUR");
            tfPrix.setText("ERREUR");
            tfAuteur.setText("ERREUR");
        }
    }
}