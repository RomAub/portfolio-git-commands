package org.example.td219012026;

import java.sql.Statement;

public class Livre {
    private String ISBN, titre, Auteur;
    private float prix;

    public String getTitre() {return titre;}
    public void setTitre(String titre) {this.titre = titre;}
    public String getAuteur() {return Auteur;}
    public void setAuteur(String auteur) {Auteur = auteur;}
    public float getPrix() {return prix;}
    public void setPrix(float prix) {this.prix = prix;}
    public String getISBN() {return ISBN;}
    public void setISBN(String iSBN) {ISBN = iSBN;}

    public Livre(String ISBN, String titre, String auteur, float prix) {
        this.ISBN = ISBN;
        this.titre = titre;
        this.Auteur = auteur;
        this.prix = prix;
    }

    public Livre(String ISBN, String titre, String auteur, float prix, Statement st) {
        this.ISBN = ISBN;
        this.titre = titre;
        this.Auteur = auteur;
        this.prix = prix;

        try {
            String sql = "INSERT INTO Livre (ISBN, titre, auteur, prix) VALUES ('"
                    + ISBN + "', '" + titre + "', '" + auteur + "', " + prix + ")";
            st.executeUpdate(sql);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void Afficher(){
        System.out.print("ISBN: " + ISBN + " | ");
        System.out.print("Titre: " + titre + ", ");
        System.out.print("Auteur: " + Auteur + ", ");
        System.out.println("Prix: " + prix + "€");
    }
}