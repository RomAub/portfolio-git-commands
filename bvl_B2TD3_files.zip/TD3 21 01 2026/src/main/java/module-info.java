module org.example.td219012026 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens org.example.td219012026 to javafx.fxml;
    exports org.example.td219012026;
}