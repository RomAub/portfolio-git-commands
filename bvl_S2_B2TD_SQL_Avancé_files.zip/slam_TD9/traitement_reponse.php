<?php
try {
    $pdo = new PDO('mysql:host=localhost;dbname=slam_TD9;charset=utf8', 'root', '');
} catch (Exception $e) { die('Erreur : ' . $e->getMessage()); }

if (!empty($_POST['login']) && !empty($_POST['contenu']) && !empty($_POST['id_question'])) {
    $login = $_POST['login'];
    $contenu = $_POST['contenu'];
    $id_q = $_POST['id_question'];
    $stmt = $pdo->prepare("SELECT u_id FROM utilisateur WHERE login = ?");
    $stmt->execute([$login]);
    $user = $stmt->fetch();

    if ($user) {
        $user_id = $user['u_id'];
    } else {
        $stmt_max = $pdo->query("SELECT MAX(u_id) FROM utilisateur");
        $user_id = $stmt_max->fetchColumn() + 1;
        $pdo->prepare("INSERT INTO utilisateur (u_id, login, annee_naissance) VALUES (?, ?, 2000)")->execute([$user_id, $login]);
    }
    $sql = "INSERT INTO reponse (r_fk_question_id, r_fk_user_id, r_date_ajout, r_contenu) VALUES (?, ?, NOW(), ?)";
    $pdo->prepare($sql)->execute([$id_q, $user_id, $contenu]);
    header("Location: page2.php?id=" . $id_q);
}
?>