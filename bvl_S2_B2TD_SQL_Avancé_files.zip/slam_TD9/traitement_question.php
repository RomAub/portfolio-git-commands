<?php
try {
    $pdo = new PDO('mysql:host=localhost;dbname=slam_TD9;charset=utf8', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (Exception $e) {
    die('Erreur : ' . $e->getMessage());
}

if (!empty($_POST['login']) && !empty($_POST['titre']) && !empty($_POST['contenu'])) {
    
    $login = $_POST['login'];
    $titre = $_POST['titre'];
    $contenu = $_POST['contenu'];

    $stmt = $pdo->prepare("SELECT u_id FROM utilisateur WHERE login = ?");
    $stmt->execute([$login]);
    $user = $stmt->fetch();

    if ($user) {
        $user_id = $user['u_id'];
    } else {
        $stmt_max = $pdo->query("SELECT MAX(u_id) FROM utilisateur");
        $user_id = $stmt_max->fetchColumn() + 1;
        $pdo->prepare("INSERT INTO utilisateur (u_id, login, annee_naissance) VALUES (?, ?, 2000)")->execute([$user_id, $login]);
    }
    $sql = "INSERT INTO question (q_titre, q_contenu, q_date_ajout, q_fk_user_id) VALUES (?, ?, NOW(), ?)";
    $pdo->prepare($sql)->execute([$titre, $contenu, $user_id]);
    header('Location: index.php');
}
?>