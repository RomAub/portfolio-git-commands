<?php
try {
    $pdo = new PDO('mysql:host=localhost;dbname=slam_TD9;charset=utf8', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (Exception $e) {
    die('Erreur : ' . $e->getMessage());
}
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die('Erreur : Aucune question sélectionnée.');
}
$id_question = $_GET['id'];
$sql_question = "SELECT q.q_titre, q.q_contenu, u.login 
                 FROM question q 
                 JOIN utilisateur u ON q.q_fk_user_id = u.u_id 
                 WHERE q.q_id = ?";
$stmt_q = $pdo->prepare($sql_question);
$stmt_q->execute([$id_question]);
$question_info = $stmt_q->fetch(PDO::FETCH_ASSOC);

if (!$question_info) {
    die('Erreur : Question introuvable.');
}
$sql_reponses = "SELECT r.r_id, r.r_contenu, u.login 
                 FROM reponse r 
                 JOIN utilisateur u ON r.r_fk_user_id = u.u_id 
                 WHERE r.r_fk_question_id = ? 
                 ORDER BY r.r_date_ajout ASC";
$stmt_r = $pdo->prepare($sql_reponses);
$stmt_r->execute([$id_question]);
$reponses = $stmt_r->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($question_info['q_titre']) ?></title>
    <style>
        .question-box { border: 2px solid #333; padding: 15px; margin-bottom: 20px; background-color: #eef; }
        .reponse-box { border: 1px solid #999; padding: 10px; margin-bottom: 10px; margin-left: 20px; background-color: #f9f9f9; }
    </style>
</head>
<body>
    <p><a href="index.php">Retour à l'accueil</a></p>
    <div class="question-box">
        <h2>Titre : <?= htmlspecialchars($question_info['q_titre']) ?></h2>
        <p><strong>Par :</strong> <?= htmlspecialchars($question_info['login']) ?></p>
        <p><strong>Contenu :</strong><br><?= nl2br(htmlspecialchars($question_info['q_contenu'])) ?></p>
    </div>

    <h3>Réponses :</h3>
    <?php if (count($reponses) > 0): ?>
        <?php foreach ($reponses as $index => $r): ?>
            <div class="reponse-box">
                <p><strong>Réponse n° <?= $index + 1 ?></strong> | Par : <?= htmlspecialchars($r['login']) ?></p>
                <p><?= nl2br(htmlspecialchars($r['r_contenu'])) ?></p>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p>Aucune réponse pour le moment. Soyez le premier !</p>
    <?php endif; ?>
    <hr>
    <h3>Ajouter une réponse</h3>
    <form action="traitement_reponse.php" method="POST">
        <input type="hidden" name="id_question" value="<?= $id_question ?>">
        <p>
            <label>Votre login :</label>
            <input type="text" name="login" required>
        </p>
        <p>
            <label>Contenu de votre réponse :</label><br>
            <textarea name="contenu" rows="3" cols="50" required></textarea>
        </p>
        <button type="submit">Envoyer la réponse</button>
    </form>
</body>
</html>