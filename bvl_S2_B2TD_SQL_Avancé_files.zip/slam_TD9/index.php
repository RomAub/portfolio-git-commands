<?php
try {
    $pdo = new PDO('mysql:host=localhost;dbname=slam_TD9;charset=utf8', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (Exception $e) {
    die('Erreur de connexion : ' . $e->getMessage());
}

$sql = "SELECT 
            q.q_id,
            q.q_titre AS Titre_question,
            u.login AS Login_user_ayant_poste,
            q.q_date_ajout AS Date_question,
            (SELECT COUNT(*) FROM reponse r WHERE r.r_fk_question_id = q.q_id) AS Nb_reponse,
            (SELECT MAX(r_date_ajout) FROM reponse r WHERE r.r_fk_question_id = q.q_id) AS Date_derniere_reponse,
            (SELECT u2.login FROM reponse r2 JOIN utilisateur u2 ON r2.r_fk_user_id = u_id WHERE r2.r_fk_question_id = q.q_id ORDER BY r2.r_date_ajout DESC LIMIT 1) AS Login_derniere_personne
        FROM question q
        JOIN utilisateur u ON q.q_fk_user_id = u.u_id";

$stmt = $pdo->query($sql);
$questions = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Forum - Accueil</title>
    <style>
        table { border-collapse: collapse; width: 100%; margin-bottom: 30px; }
        th, td { border: 1px solid black; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <h1>Forum de discussion</h1>

    <table>
        <thead>
            <tr>
                <th>Titre question</th>
                <th>Login user ayant posté</th>
                <th>Date question</th>
                <th>Nb réponse</th>
                <th>Date de dernière réponse</th>
                <th>Login de la dernière personne ayant répondu</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($questions as $q): ?>
            <tr>
                <td><a href="page2.php?id=<?= $q['q_id'] ?>"><?= htmlspecialchars($q['Titre_question']) ?></a></td>
                <td><?= htmlspecialchars($q['Login_user_ayant_poste']) ?></td>
                <td><?= $q['Date_question'] ?></td>
                <td><?= $q['Nb_reponse'] ?></td>
                <td><?= $q['Date_derniere_reponse'] ?: 'Aucune réponse' ?></td>
                <td><?= $q['Login_derniere_personne'] ?: '-' ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <h2>Poser une nouvelle question</h2>
    <form action="traitement_question.php" method="POST">
        <p>
            <label>Votre login :</label>
            <input type="text" name="login" required>
        </p>
        <p>
            <label>Titre :</label>
            <input type="text" name="titre" required>
        </p>
        <p>
            <label>Contenu :</label><br>
            <textarea name="contenu" rows="4" cols="50" required></textarea>
        </p>
        <button type="submit">Poster la question</button>
    </form>
</body>
</html>