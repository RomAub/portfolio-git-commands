SET sql_mode = ORACLE;
TRUNCATE TABLE sortie;

DELIMITER $$
DECLARE
  CURSOR c_emp IS SELECT nom, salaire FROM employes WHERE dept_id = 30;
  cursor_already_open CONDITION FOR 1325;
BEGIN
  OPEN c_emp;
  OPEN c_emp;
EXCEPTION
  WHEN cursor_already_open THEN
    afficher('Erreur 1 : le curseur est déjà ouvert !');
END;
$$

DECLARE
  CURSOR c_emp IS SELECT nom, salaire FROM employes WHERE dept_id = 30;
  v_nom     employes.nom%TYPE;
  v_salaire employes.salaire%TYPE;
BEGIN
  FETCH c_emp INTO v_nom, v_salaire;
EXCEPTION
  WHEN INVALID_CURSOR THEN
    afficher('Erreur 2 : on ne peut pas lire un curseur qui n''est pas ouvert !');
END;
$$
DELIMITER ;

SELECT ligne FROM sortie ORDER BY num;
