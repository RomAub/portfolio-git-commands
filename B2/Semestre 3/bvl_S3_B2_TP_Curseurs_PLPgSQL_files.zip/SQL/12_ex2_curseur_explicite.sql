SET sql_mode = ORACLE;
TRUNCATE TABLE sortie;

DELIMITER $$
CREATE OR REPLACE FUNCTION bool_txt(p_val NUMBER) RETURN VARCHAR2 AS
BEGIN
  IF p_val IS NULL THEN
    RETURN 'NULL';
  ELSIF p_val = 1 THEN
    RETURN 'TRUE';
  ELSE
    RETURN 'FALSE';
  END IF;
END;
$$

DECLARE
  CURSOR c_emp IS SELECT nom, salaire FROM employes WHERE dept_id = 30;
  v_nom     employes.nom%TYPE;
  v_salaire employes.salaire%TYPE;
BEGIN
  afficher('Avant OPEN      : ISOPEN=' || bool_txt(c_emp%ISOPEN));

  OPEN c_emp;
  afficher('Après OPEN      : ISOPEN=' || bool_txt(c_emp%ISOPEN)
        || ' FOUND=' || bool_txt(c_emp%FOUND)
        || ' NOTFOUND=' || bool_txt(c_emp%NOTFOUND)
        || ' ROWCOUNT=' || c_emp%ROWCOUNT);

  FETCH c_emp INTO v_nom, v_salaire;
  afficher('Ligne lue : ' || v_nom || ' - ' || v_salaire || ' €');
  afficher('Après 1er FETCH : ISOPEN=' || bool_txt(c_emp%ISOPEN)
        || ' FOUND=' || bool_txt(c_emp%FOUND)
        || ' NOTFOUND=' || bool_txt(c_emp%NOTFOUND)
        || ' ROWCOUNT=' || c_emp%ROWCOUNT);

  CLOSE c_emp;
  afficher('Après CLOSE     : ISOPEN=' || bool_txt(c_emp%ISOPEN));
END;
$$
DELIMITER ;

SELECT ligne FROM sortie ORDER BY num;
