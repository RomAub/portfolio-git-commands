SET sql_mode = ORACLE;
SET autocommit = 0;
TRUNCATE TABLE sortie;

DELIMITER $$
DECLARE
  CURSOR c_prime IS
    SELECT emp_id, nom, salaire FROM employes
    WHERE dept_id = 10 AND prime IS NULL
    FOR UPDATE;
BEGIN
  FOR r IN c_prime LOOP
    UPDATE employes SET prime = r.salaire * 0.05 WHERE emp_id = r.emp_id;
    afficher(r.nom || ' : nouvelle prime de ' || r.salaire * 0.05 || ' €');
  END LOOP;

  DO SLEEP(30);
  COMMIT;
END;
$$
DELIMITER ;

SELECT ligne FROM sortie ORDER BY num;
