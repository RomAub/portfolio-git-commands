DELIMITER $$
DECLARE
  CURSOR c_emp IS SELECT nom, salaire FROM employes WHERE dept_id = 30;
  v_nom     employes.nom%TYPE;
  v_salaire employes.salaire%TYPE;
BEGIN
  FETCH c_emp INTO v_nom, v_salaire;
  OPEN c_emp;
  CLOSE c_emp;
END;
$$
DELIMITER ;

DELIMITER $$
DECLARE
  CURSOR c_emp IS SELECT nom, salaire FROM employes WHERE dept_id = 30;
BEGIN
  OPEN c_emp;
  OPEN c_emp;
  CLOSE c_emp;
END;
$$
DELIMITER ;

DELIMITER $$
DECLARE
  CURSOR c_emp IS SELECT nom, salaire FROM employes WHERE dept_id = 30;
BEGIN
  OPEN c_emp;
  CLOSE c_emp;
  CLOSE c_emp;
END;
$$
DELIMITER ;

DELIMITER $$
DECLARE
  CURSOR c_emp IS SELECT nom, salaire FROM employes WHERE dept_id = 30;
  v_nom     NUMBER;
  v_salaire employes.salaire%TYPE;
BEGIN
  OPEN c_emp;
  FETCH c_emp INTO v_nom, v_salaire;
  afficher('Nom lu : ' || v_nom || ' / salaire : ' || v_salaire);
  CLOSE c_emp;
END;
$$
DELIMITER ;

DELIMITER $$
DECLARE
  CURSOR c_emp IS SELECT nom, salaire FROM employes WHERE dept_id = 30;
  v_nom employes.nom%TYPE;
BEGIN
  OPEN c_emp;
  FETCH c_emp INTO v_nom;
  CLOSE c_emp;
END;
$$
DELIMITER ;
