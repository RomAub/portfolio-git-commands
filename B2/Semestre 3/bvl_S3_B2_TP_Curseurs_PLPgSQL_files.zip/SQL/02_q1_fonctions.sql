SET sql_mode = ORACLE;

DELIMITER $$
CREATE OR REPLACE FUNCTION nb_factures(p_num_client NUMBER) RETURN NUMBER AS
  v_nb NUMBER;
BEGIN
  SELECT COUNT(*) INTO v_nb
  FROM facture
  WHERE num_client = p_num_client;
  RETURN v_nb;
END;
$$

CREATE OR REPLACE FUNCTION chiffre_affaire(p_num_client NUMBER) RETURN NUMBER AS
  v_ca NUMBER;
BEGIN
  SELECT NVL(SUM(c.quantite * p.prix), 0) INTO v_ca
  FROM facture f
  JOIN concerne c ON c.num_facture = f.num
  JOIN produit p ON p.num = c.num_produit
  WHERE f.num_client = p_num_client;
  RETURN v_ca;
END;
$$
DELIMITER ;

SELECT num, nom, nb_factures(num) AS nb_factures, chiffre_affaire(num) AS ca
FROM client;
