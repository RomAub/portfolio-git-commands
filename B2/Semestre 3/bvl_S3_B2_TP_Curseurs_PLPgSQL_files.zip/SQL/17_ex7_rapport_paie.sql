SET sql_mode = ORACLE;

DELIMITER $$
CREATE OR REPLACE PROCEDURE rapport_paie(p_dept NUMBER) AS
  CURSOR c_dept IS
    SELECT dept_id, dept_nom FROM departements
    WHERE p_dept IS NULL OR dept_id = p_dept
    ORDER BY dept_id;
  CURSOR c_emp(p_id NUMBER) IS
    SELECT nom, salaire, prime FROM employes
    WHERE dept_id = p_id
    ORDER BY salaire DESC;
  v_nb           NUMBER;
  v_total_sal    NUMBER;
  v_total_prime  NUMBER;
  v_max          NUMBER;
  v_general      NUMBER := 0;
  v_nb_dept      NUMBER := 0;
  e_dept_inconnu EXCEPTION;
BEGIN
  afficher('========== RAPPORT DE PAIE ==========');

  FOR d IN c_dept LOOP
    v_nb_dept := v_nb_dept + 1;
    v_nb := 0;
    v_total_sal := 0;
    v_total_prime := 0;
    v_max := 0;
    afficher('>> Département ' || d.dept_id || ' : ' || d.dept_nom);

    FOR e IN c_emp(d.dept_id) LOOP
      v_nb := v_nb + 1;
      v_total_sal := v_total_sal + e.salaire;
      v_total_prime := v_total_prime + NVL(e.prime, 0);
      IF e.salaire > v_max THEN
        v_max := e.salaire;
      END IF;
      afficher('   ' || e.nom || ' | salaire ' || e.salaire || ' € | prime '
            || CASE WHEN e.prime IS NULL THEN 'aucune' ELSE e.prime || ' €' END);
    END LOOP;

    IF v_nb = 0 THEN
      afficher('   (département vide, aucun employé)');
    ELSE
      afficher('   Total : ' || v_total_sal || ' € de salaires + ' || v_total_prime
            || ' € de primes | Salaire max : ' || v_max || ' €');
    END IF;
    v_general := v_general + v_total_sal + v_total_prime;
  END LOOP;

  IF v_nb_dept = 0 THEN
    RAISE e_dept_inconnu;
  END IF;

  afficher('=====================================');
  afficher('TOTAL GÉNÉRAL (salaires + primes) : ' || v_general || ' €');
EXCEPTION
  WHEN e_dept_inconnu THEN
    afficher('Erreur : le département ' || p_dept || ' n''existe pas');
  WHEN OTHERS THEN
    afficher('Erreur pendant le rapport (' || SQLCODE || ') : ' || SQLERRM);
END;
$$
DELIMITER ;

TRUNCATE TABLE sortie;
CALL rapport_paie(NULL);
SELECT ligne FROM sortie ORDER BY num;
