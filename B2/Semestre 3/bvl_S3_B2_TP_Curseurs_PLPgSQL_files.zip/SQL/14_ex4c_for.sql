SET sql_mode = ORACLE;
TRUNCATE TABLE sortie;

DELIMITER $$
DECLARE
  CURSOR c_emp IS SELECT nom, salaire FROM employes WHERE dept_id = 30 ORDER BY emp_id;
BEGIN
  FOR rec IN c_emp LOOP
    afficher(rec.nom || ' : ' || rec.salaire || ' €');
  END LOOP;
END;
$$
DELIMITER ;

SELECT ligne FROM sortie ORDER BY num;
