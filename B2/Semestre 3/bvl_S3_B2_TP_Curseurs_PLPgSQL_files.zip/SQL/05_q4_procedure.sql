SET sql_mode = ORACLE;

DELIMITER $$
CREATE OR REPLACE PROCEDURE etat_clients AS
  CURSOR c_clients IS SELECT num FROM client ORDER BY num;
BEGIN
  FOR r IN c_clients LOOP
    afficher('Client ' || r.num);
    afficher(nb_factures(r.num) || ' / ' || chiffre_affaire(r.num));
    afficher('------------------');
  END LOOP;
END;
$$
DELIMITER ;

TRUNCATE TABLE sortie;
CALL etat_clients();
SELECT ligne FROM sortie ORDER BY num;
