SET sql_mode = ORACLE;
SET autocommit = 0;
TRUNCATE TABLE sortie;

DELIMITER $$
BEGIN
  UPDATE employes SET salaire = salaire WHERE dept_id = 20;
  afficher('Lignes : ' || SQL%ROWCOUNT);
  ROLLBACK;
END;
$$
DELIMITER ;

SELECT ligne FROM sortie ORDER BY num;
