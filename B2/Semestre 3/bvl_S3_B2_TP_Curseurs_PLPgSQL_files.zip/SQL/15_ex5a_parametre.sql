SET sql_mode = ORACLE;
TRUNCATE TABLE sortie;

DELIMITER $$
DECLARE
  CURSOR c_emp(p_dept NUMBER, p_seuil NUMBER) IS
    SELECT nom, salaire FROM employes
    WHERE dept_id = p_dept AND salaire > p_seuil
    ORDER BY salaire DESC;
BEGIN
  afficher('--- Département 30, salaire > 3000 ---');
  FOR rec IN c_emp(30, 3000) LOOP
    afficher(rec.nom || ' : ' || rec.salaire || ' €');
  END LOOP;

  afficher('--- Département 10, salaire > 2000 ---');
  FOR rec IN c_emp(10, 2000) LOOP
    afficher(rec.nom || ' : ' || rec.salaire || ' €');
  END LOOP;
END;
$$
DELIMITER ;

SELECT ligne FROM sortie ORDER BY num;
