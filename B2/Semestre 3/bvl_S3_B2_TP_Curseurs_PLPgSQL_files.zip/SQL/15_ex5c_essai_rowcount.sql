SET sql_mode = ORACLE;
TRUNCATE TABLE sortie;

DELIMITER $$
DECLARE
  CURSOR c_dept IS SELECT dept_id, dept_nom FROM departements ORDER BY dept_id;
  CURSOR c_emp(p_dept NUMBER, p_seuil NUMBER) IS
    SELECT nom, salaire FROM employes
    WHERE dept_id = p_dept AND salaire > p_seuil
    ORDER BY salaire DESC;
BEGIN
  FOR d IN c_dept LOOP
    afficher('=== ' || d.dept_id || ' - ' || d.dept_nom || ' ===');
    FOR e IN c_emp(d.dept_id, 2500) LOOP
      afficher('- ' || e.nom || ' : ' || e.salaire || ' €');
    END LOOP;
    IF c_emp%ROWCOUNT = 0 THEN
      afficher('aucun employé');
    END IF;
  END LOOP;
END;
$$
DELIMITER ;

SELECT ligne FROM sortie ORDER BY num;
