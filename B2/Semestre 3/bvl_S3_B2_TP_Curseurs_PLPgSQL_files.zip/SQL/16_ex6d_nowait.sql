SET sql_mode = ORACLE;
SET autocommit = 0;
SET innodb_lock_wait_timeout = 1;
TRUNCATE TABLE sortie;

DELIMITER $$
DECLARE
  CURSOR c_prime IS
    SELECT emp_id, nom, salaire FROM employes
    WHERE dept_id = 10 AND prime IS NULL
    FOR UPDATE;
  ligne_verrouillee CONDITION FOR 1205;
BEGIN
  FOR r IN c_prime LOOP
    UPDATE employes SET prime = r.salaire * 0.05 WHERE emp_id = r.emp_id;
    afficher(r.nom || ' : nouvelle prime de ' || r.salaire * 0.05 || ' €');
  END LOOP;
  COMMIT;
EXCEPTION
  WHEN ligne_verrouillee THEN
    afficher('Lignes déjà verrouillées par une autre session, on réessaiera plus tard');
    ROLLBACK;
END;
$$
DELIMITER ;

SELECT ligne FROM sortie ORDER BY num;
