SET sql_mode = ORACLE;

CREATE TABLE client (
  num            NUMBER(5) PRIMARY KEY,
  nom            VARCHAR2(30),
  prenom         VARCHAR2(30),
  adresse        VARCHAR2(80),
  date_naissance DATE,
  tel            VARCHAR2(14),
  sexe           CHAR(1)
);

CREATE TABLE produit (
  num         NUMBER(5) PRIMARY KEY,
  designation VARCHAR2(50),
  prix        NUMBER(8,2),
  stock       NUMBER(5)
);

CREATE TABLE facture (
  num          NUMBER(5) PRIMARY KEY,
  date_facture DATE,
  num_client   NUMBER(5) NOT NULL,
  CONSTRAINT fk_facture_client FOREIGN KEY (num_client) REFERENCES client(num)
);

CREATE TABLE concerne (
  num_facture NUMBER(5),
  num_produit NUMBER(5),
  quantite    NUMBER(3),
  CONSTRAINT pk_concerne PRIMARY KEY (num_facture, num_produit),
  CONSTRAINT fk_concerne_facture FOREIGN KEY (num_facture) REFERENCES facture(num),
  CONSTRAINT fk_concerne_produit FOREIGN KEY (num_produit) REFERENCES produit(num)
);

INSERT INTO client VALUES (1, 'Dupont', 'Marie', '12 rue des Lilas, Lyon', DATE '1995-04-12', '06 12 34 56 78', 'F');
INSERT INTO client VALUES (2, 'Lefebvre', 'Thomas', '3 place Bellecour, Lyon', DATE '1988-11-02', '06 98 76 54 32', 'M');
INSERT INTO client VALUES (3, 'Moreau', 'Julie', '45 avenue Jean Jaurès, Villeurbanne', DATE '2001-07-23', '07 11 22 33 44', 'F');
INSERT INTO client VALUES (4, 'Bernard', 'Lucas', '8 rue Victor Hugo, Bron', DATE '1979-01-30', '06 55 44 33 22', 'M');
INSERT INTO client VALUES (5, 'Petit', 'Emma', '27 rue de la République, Lyon', DATE '2003-09-15', '07 66 77 88 99', 'F');

INSERT INTO produit VALUES (1, 'DVD Inception', 12.99, 40);
INSERT INTO produit VALUES (2, 'Blu-ray Dune', 19.99, 25);
INSERT INTO produit VALUES (3, 'CD Daft Punk - Discovery', 15.50, 30);
INSERT INTO produit VALUES (4, 'Livre SQL pour les nuls', 24.90, 15);
INSERT INTO produit VALUES (5, 'BD Astérix', 11.95, 50);
INSERT INTO produit VALUES (6, 'Casque audio', 49.90, 10);

INSERT INTO facture VALUES (1, DATE '2026-01-05', 1);
INSERT INTO facture VALUES (2, DATE '2026-01-18', 2);
INSERT INTO facture VALUES (3, DATE '2026-02-02', 1);
INSERT INTO facture VALUES (4, DATE '2026-02-14', 3);
INSERT INTO facture VALUES (5, DATE '2026-03-01', 1);
INSERT INTO facture VALUES (6, DATE '2026-03-22', 4);
INSERT INTO facture VALUES (7, DATE '2026-04-09', 2);
INSERT INTO facture VALUES (8, DATE '2026-05-17', 3);
INSERT INTO facture VALUES (9, DATE '2026-06-03', 1);
INSERT INTO facture VALUES (10, DATE '2026-06-28', 4);

INSERT INTO concerne VALUES (1, 1, 2);
INSERT INTO concerne VALUES (1, 3, 1);
INSERT INTO concerne VALUES (2, 4, 1);
INSERT INTO concerne VALUES (3, 2, 1);
INSERT INTO concerne VALUES (3, 5, 3);
INSERT INTO concerne VALUES (4, 6, 1);
INSERT INTO concerne VALUES (5, 5, 2);
INSERT INTO concerne VALUES (6, 1, 1);
INSERT INTO concerne VALUES (6, 2, 1);
INSERT INTO concerne VALUES (6, 3, 1);
INSERT INTO concerne VALUES (7, 6, 1);
INSERT INTO concerne VALUES (7, 3, 2);
INSERT INTO concerne VALUES (8, 4, 2);
INSERT INTO concerne VALUES (9, 1, 1);
INSERT INTO concerne VALUES (10, 5, 1);
INSERT INTO concerne VALUES (10, 4, 1);
