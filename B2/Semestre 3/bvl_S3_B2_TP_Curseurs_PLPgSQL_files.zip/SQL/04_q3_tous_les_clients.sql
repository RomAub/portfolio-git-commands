SET sql_mode = ORACLE;
TRUNCATE TABLE sortie;

DELIMITER $$
DECLARE
  CURSOR c_clients IS SELECT num FROM client ORDER BY num;
BEGIN
  FOR r IN c_clients LOOP
    afficher('Client ' || r.num);
    afficher(nb_factures(r.num) || ' / ' || chiffre_affaire(r.num));
    afficher('------------------');
  END LOOP;
END;
$$
DELIMITER ;

SELECT ligne FROM sortie ORDER BY num;
