SET sql_mode = ORACLE;
TRUNCATE TABLE sortie;

DELIMITER $$
DECLARE
  v_client client.num%TYPE := 1;
BEGIN
  afficher('Client ' || v_client);
  afficher('Nombre de factures : ' || nb_factures(v_client));
  afficher('Chiffre d''affaire : ' || chiffre_affaire(v_client) || ' €');
END;
$$
DELIMITER ;

SELECT ligne FROM sortie ORDER BY num;
