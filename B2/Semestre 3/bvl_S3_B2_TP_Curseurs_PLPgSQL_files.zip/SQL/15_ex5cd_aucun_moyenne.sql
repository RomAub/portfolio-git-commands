SET sql_mode = ORACLE;
TRUNCATE TABLE sortie;

DELIMITER $$
DECLARE
  CURSOR c_dept IS SELECT dept_id, dept_nom FROM departements ORDER BY dept_id;
  CURSOR c_emp(p_dept NUMBER, p_seuil NUMBER) IS
    SELECT nom, salaire FROM employes
    WHERE dept_id = p_dept AND salaire > p_seuil
    ORDER BY salaire DESC;
  v_nb    NUMBER;
  v_total NUMBER;
BEGIN
  FOR d IN c_dept LOOP
    afficher('=== ' || d.dept_id || ' - ' || d.dept_nom || ' ===');
    v_nb := 0;
    v_total := 0;
    FOR e IN c_emp(d.dept_id, 2500) LOOP
      afficher('- ' || e.nom || ' : ' || e.salaire || ' €');
      v_nb := v_nb + 1;
      v_total := v_total + e.salaire;
    END LOOP;

    IF v_nb = 0 THEN
      afficher('aucun employé');
    ELSE
      afficher('Salaire moyen : ' || ROUND(v_total / v_nb, 2) || ' €');
    END IF;
  END LOOP;
END;
$$
DELIMITER ;

SELECT ligne FROM sortie ORDER BY num;
