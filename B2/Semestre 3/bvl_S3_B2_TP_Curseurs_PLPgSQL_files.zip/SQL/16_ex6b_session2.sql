UPDATE employes SET salaire = salaire + 1 WHERE nom = 'Durand';
