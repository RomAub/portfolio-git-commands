SET sql_mode = ORACLE;
TRUNCATE TABLE sortie;

DELIMITER $$
DECLARE
  CURSOR c_emp IS SELECT nom, salaire FROM employes WHERE dept_id = 30 ORDER BY emp_id;
  v_nom     employes.nom%TYPE;
  v_salaire employes.salaire%TYPE;
BEGIN
  OPEN c_emp;
  LOOP
    FETCH c_emp INTO v_nom, v_salaire;
    afficher(c_emp%ROWCOUNT || '. ' || v_nom || ' : ' || v_salaire || ' €');
    EXIT WHEN c_emp%NOTFOUND;
  END LOOP;
  CLOSE c_emp;
END;
$$
DELIMITER ;

SELECT ligne FROM sortie ORDER BY num;
