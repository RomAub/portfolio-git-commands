SET sql_mode = ORACLE;
SET autocommit = 0;
TRUNCATE TABLE sortie;

DELIMITER $$
DECLARE
  CURSOR c_rh IS
    SELECT emp_id, nom, prime FROM employes
    WHERE dept_id = 20
    FOR UPDATE;
BEGIN
  FOR r IN c_rh LOOP
    UPDATE employes SET prime = NVL(r.prime, 0) + 50 WHERE emp_id = r.emp_id;
    COMMIT;
    afficher(r.nom || ' : prime passée à ' || (NVL(r.prime, 0) + 50) || ' € (COMMIT fait)');
  END LOOP;
END;
$$
DELIMITER ;

SELECT ligne FROM sortie ORDER BY num;
