SET sql_mode = ORACLE;

DELIMITER $$
DECLARE v_nom employes.nom%TYPE;
BEGIN
  SELECT nom INTO v_nom FROM employes WHERE dept_id = 99;
END;
$$
DELIMITER ;
