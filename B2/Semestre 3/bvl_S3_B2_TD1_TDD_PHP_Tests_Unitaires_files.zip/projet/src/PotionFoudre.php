<?php

namespace Romain\Td1;

class PotionFoudre
{
    private const RECETTE = [
        'nuages_tenebreux' => 2,
        'poussiere_fee' => 1,
    ];

    public function nbPotionsFoudreRealisables(array $ingredients): int
    {
        if (empty($ingredients)) {
            return 0;
        }

        $nbPotions = max($ingredients);

        foreach (self::RECETTE as $ingredient => $quantiteNecessaire) {
            if (!isset($ingredients[$ingredient]) || $ingredients[$ingredient] < $quantiteNecessaire) {
                return 0;
            }

            $nbPotions = min($nbPotions, intdiv($ingredients[$ingredient], $quantiteNecessaire));
        }

        return $nbPotions;
    }
}
