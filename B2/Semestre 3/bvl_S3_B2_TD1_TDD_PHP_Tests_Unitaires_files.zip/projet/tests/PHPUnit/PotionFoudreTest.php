<?php

namespace Tests\PHPUnit;

use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;
use Romain\Td1\PotionFoudre;

final class PotionFoudreTest extends TestCase
{
    private PotionFoudre $potion;

    protected function setUp(): void
    {
        parent::setUp();
        $this->potion = new PotionFoudre();
    }

    public static function jeuDeTests(): array
    {
        return [
            '2 ingrédients, dans les quantités requises' => [['nuages_tenebreux' => 2, 'poussiere_fee' => 1], 1],
            '2 ingrédients, mais pas assez du premier' => [['nuages_tenebreux' => 1, 'poussiere_fee' => 1], 0],
            '2 ingrédients, dans les quantités X fois requises' => [['nuages_tenebreux' => 8, 'poussiere_fee' => 4], 4],
            'manque l\'ingrédient 1' => [['poussiere_fee' => 1], 0],
            'manque l\'ingrédient 2' => [['nuages_tenebreux' => 2], 0],
            'ingrédients autres' => [['queue_lezard' => 5, 'eau_jouvence' => 2], 0],
            'Aucun ingrédient' => [[], 0],
            'Beaucoup ingrédient 1' => [['nuages_tenebreux' => 250, 'poussiere_fee' => 1], 1],
            'Beaucoup ingrédient 2' => [['nuages_tenebreux' => 2, 'poussiere_fee' => 120], 1],
        ];
    }

    #[DataProvider('jeuDeTests')]
    public function testNbPotionsFoudreRealisables(array $ingredients, int $potionsAttendues): void
    {
        $this->assertSame($potionsAttendues, $this->potion->nbPotionsFoudreRealisables($ingredients));
    }
}
