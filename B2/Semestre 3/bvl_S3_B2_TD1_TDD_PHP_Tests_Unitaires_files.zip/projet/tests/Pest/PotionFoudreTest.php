<?php

use Romain\Td1\PotionFoudre;

beforeEach(function () {
    $this->potion = new PotionFoudre();
});

it('calcule le nombre de potions de foudre réalisables', function (array $ingredients, int $potionsAttendues) {
    expect($this->potion->nbPotionsFoudreRealisables($ingredients))->toBe($potionsAttendues);
})->with([
    '2 ingrédients, dans les quantités requises' => [['nuages_tenebreux' => 2, 'poussiere_fee' => 1], 1],
    '2 ingrédients, mais pas assez du premier' => [['nuages_tenebreux' => 1, 'poussiere_fee' => 1], 0],
    '2 ingrédients, dans les quantités X fois requises' => [['nuages_tenebreux' => 8, 'poussiere_fee' => 4], 4],
    'manque l\'ingrédient 1' => [['poussiere_fee' => 1], 0],
    'manque l\'ingrédient 2' => [['nuages_tenebreux' => 2], 0],
    'ingrédients autres' => [['queue_lezard' => 5, 'eau_jouvence' => 2], 0],
    'Aucun ingrédient' => [[], 0],
    'Beaucoup ingrédient 1' => [['nuages_tenebreux' => 250, 'poussiere_fee' => 1], 1],
    'Beaucoup ingrédient 2' => [['nuages_tenebreux' => 2, 'poussiere_fee' => 120], 1],
]);

test('une potion ne peut pas être réalisée sans recette complète', function () {
    expect($this->potion->nbPotionsFoudreRealisables(['nuages_tenebreux' => 10]))->toBe(0)
        ->and($this->potion->nbPotionsFoudreRealisables(['poussiere_fee' => 10]))->toBe(0);
});
