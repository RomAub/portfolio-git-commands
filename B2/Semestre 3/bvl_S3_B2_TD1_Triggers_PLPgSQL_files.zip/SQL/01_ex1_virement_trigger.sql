-- ==========================================================
-- SLAM 3.5 - TD 8 : Les Triggers (base HHB-Direct)
-- Aubrée Romain - SLAM Groupe 1 - 09/10/2026
-- Exercice 1 : mise à jour automatique des soldes lors d'un virement
-- ==========================================================

-- Fonction virement() (reprise du TP hhb-direct).
-- Elle insère une opération de type VIREMENT après avoir vérifié que les 2 comptes
-- existent et que le compte débiteur reste créditeur. Elle ne met PAS à jour les
-- soldes : c'est le trigger ci-dessous qui s'en charge automatiquement.
CREATE OR REPLACE FUNCTION virement(
	p_num_compte_de integer, p_id_type_de integer,
	p_num_compte_vers integer, p_id_type_vers integer,
	p_montant integer, p_designation varchar)
RETURNS integer
LANGUAGE plpgsql
AS $function$
	declare
		solde_de integer ;
		existe_de integer ;
		existe_vers integer ;
		new_id bigint ;
	begin
		-- existence des 2 comptes
		existe_de := (select count(*) from compte
			where num_compte = p_num_compte_de and id_type = p_id_type_de) ;
		existe_vers := (select count(*) from compte
			where num_compte = p_num_compte_vers and id_type = p_id_type_vers) ;
		if existe_de = 0 or existe_vers = 0 then
			return 0 ;
		end if ;

		-- le compte débiteur doit rester créditeur après le virement
		select solde into solde_de from compte
			where num_compte = p_num_compte_de and id_type = p_id_type_de ;
		if solde_de - p_montant < 0 then
			return 0 ;
		end if ;

		-- la date du jour doit exister dans la table date (intégrité référentielle)
		if not exists (select 1 from date where date = current_date) then
			insert into date values (current_date) ;
		end if ;

		-- insertion de l'opération de virement (les soldes seront mis à jour par le trigger)
		select coalesce(max(id_operation), 0) + 1 into new_id from operation ;
		insert into operation(id_operation, num_compte, date, id_type, id_type_vers,
			num_compte_vers, designation, type_operation, montant)
		values (new_id, p_num_compte_de, current_date, p_id_type_de, p_id_type_vers,
			p_num_compte_vers, p_designation, 'VIREMENT', p_montant) ;
		return 1 ;
	end ;
$function$ ;

-- Fonction associée au trigger : mise à jour des 2 soldes
CREATE OR REPLACE FUNCTION Insert_operation_virement() RETURNS trigger
LANGUAGE plpgsql
AS $function$
	begin
		-- on agit UNIQUEMENT pour les opérations de type virement
		if NEW.type_operation = 'VIREMENT' then
			-- débit du compte source
			update compte set solde = solde - NEW.montant
				where num_compte = NEW.num_compte and id_type = NEW.id_type ;
			-- crédit du compte destination
			update compte set solde = solde + NEW.montant
				where num_compte = NEW.num_compte_vers and id_type = NEW.id_type_vers ;
		end if ;
		return null ; -- trigger AFTER : ne renvoie rien
	end ;
$function$ ;

-- Déclencheur AFTER INSERT sur operation
DROP TRIGGER IF EXISTS Trig_insert_operation_virement ON operation ;
CREATE TRIGGER Trig_insert_operation_virement AFTER INSERT
	ON operation FOR EACH ROW
	EXECUTE PROCEDURE Insert_operation_virement() ;

-- --- Test ---
-- Soldes avant : compte (1,1) = 1000 ; compte (3,1) = 3400
-- select num_compte, id_type, solde from compte where (num_compte,id_type) in ((1,1),(3,1));
-- select virement(1, 1, 3, 1, 200, 'Virement test TD8');
-- Soldes après : compte (1,1) = 800 ; compte (3,1) = 3600
