-- ==========================================================
-- SLAM 3.5 - TD 8 : Les Triggers (base HHB-Direct)
-- Aubrée Romain - SLAM Groupe 1 - 09/10/2026
-- Exercice 3 : contrôle du chevauchement des périodes de rémunération
-- ==========================================================

-- Fonction associée au trigger : à l'insertion d'une nouvelle rémunération, on
-- vérifie que le début de la nouvelle période est postérieur à la fin de la
-- période précédente, pour un même type de compte.
CREATE OR REPLACE FUNCTION Insert_remuneration() RETURNS trigger
LANGUAGE plpgsql
AS $function$
	declare
		fin_precedente date ;
	begin
		-- fin de la dernière période de rémunération existante pour ce type de compte
		select max(date) into fin_precedente
		from remunerer
		where id_type = NEW.id_type ;

		-- si une période existe déjà, la nouvelle doit commencer après sa fin
		if fin_precedente is not null and NEW.date_de <= fin_precedente then
			raise exception 'Chevauchement de periode pour le type de compte % : le debut % doit etre posterieur a la fin de la periode precedente (%)',
				NEW.id_type, NEW.date_de, fin_precedente ;
		end if ;

		return NEW ; -- trigger BEFORE : insertion acceptée
	end ;
$function$ ;

-- Déclencheur BEFORE INSERT sur remunerer
DROP TRIGGER IF EXISTS Trig_insert_remuneration ON remunerer ;
CREATE TRIGGER Trig_insert_remuneration BEFORE INSERT
	ON remunerer FOR EACH ROW
	EXECUTE PROCEDURE Insert_remuneration() ;

-- --- Test ---
-- Périodes existantes pour id_type 2 : 01/01/2012->01/11/2012 et 02/11/2012->31/12/2012
-- Cas valide (début 01/01/2013 > fin 31/12/2012) :
--   -- les 2 dates doivent d'abord exister dans la table calendrier "date"
--   insert into date values ('2013-01-01'), ('2013-06-30') ;
--   insert into remunerer(date_de, date, id_type, taux_interet)
--     values ('2013-01-01', '2013-06-30', 2, 3) ;
-- Cas refusé (début 15/12/2012 <= fin 31/12/2012) :
--   insert into remunerer(date_de, date, id_type, taux_interet)
--     values ('2012-12-15', '2013-02-01', 2, 5) ;
