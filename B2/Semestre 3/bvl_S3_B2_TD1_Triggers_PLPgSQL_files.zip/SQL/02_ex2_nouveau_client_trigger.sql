-- ==========================================================
-- SLAM 3.5 - TD 8 : Les Triggers (base HHB-Direct)
-- Aubrée Romain - SLAM Groupe 1 - 09/10/2026
-- Exercice 2 : complétion automatique d'un nouveau client
-- ==========================================================

-- Fonction déjà définie au TD précédent : identifiant / mot de passe internet.
-- (1ère lettre du prénom en majuscule + nom en minuscule, + un numéro s'il y a homonymie)
CREATE OR REPLACE FUNCTION creer_id_internet(p_nom varchar, p_prenom varchar)
RETURNS varchar
LANGUAGE plpgsql
AS $function$
	declare
		id_internet varchar ;
		nb integer ;
	begin
		id_internet := upper(substr(p_prenom, 1, 1)) || lower(p_nom) ;
		select count(*) into nb
		from client
		where upper(nom_client) = upper(p_nom)
		and upper(prenom_client) = upper(p_prenom) ;
		if nb > 0 then
			id_internet := id_internet || nb ;
		end if ;
		return id_internet ;
	end ;
$function$ ;

-- Fonction associée au trigger : à l'insertion d'un client, on détermine son
-- identifiant / mot de passe internet (s'ils ne sont pas saisis) puis on crée
-- son compte de connexion à PostgreSQL.
CREATE OR REPLACE FUNCTION Insert_nouveau_client() RETURNS trigger
LANGUAGE plpgsql
AS $function$
	declare
		id varchar ;
	begin
		-- identifiant / mot de passe internet via la fonction déjà définie
		if NEW.identifiant_internet is null then
			id := creer_id_internet(NEW.nom_client, NEW.prenom_client) ;
			NEW.identifiant_internet := id ;
			NEW.mdp_internet := id ;
		end if ;

		-- création du compte de connexion PostgreSQL du client (s'il n'existe pas déjà)
		if not exists (select 1 from pg_roles where rolname = NEW.identifiant_internet) then
			execute format('CREATE ROLE %I LOGIN PASSWORD %L',
				NEW.identifiant_internet, NEW.mdp_internet) ;
		end if ;

		return NEW ; -- trigger BEFORE : le client est inséré avec les valeurs complétées
	end ;
$function$ ;

-- Déclencheur BEFORE INSERT sur client
DROP TRIGGER IF EXISTS Trig_insert_nouveau_client ON client ;
CREATE TRIGGER Trig_insert_nouveau_client BEFORE INSERT
	ON client FOR EACH ROW
	EXECUTE PROCEDURE Insert_nouveau_client() ;

-- --- Test ---
-- insert into client(num_client, nom_client, prenom_client, adresse_client)
--   values (6, 'MARTIN', 'Julie', '8 Rue des Lilas, 22300 LANNION') ;
-- select num_client, nom_client, prenom_client, identifiant_internet, mdp_internet
--   from client where num_client = 6 ;
-- select rolname, rolcanlogin from pg_roles where rolname = 'Jmartin' ;
