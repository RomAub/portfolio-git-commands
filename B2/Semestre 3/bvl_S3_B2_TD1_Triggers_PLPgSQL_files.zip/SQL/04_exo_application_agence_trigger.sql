-- ==========================================================
-- SLAM 3.5 - TD 8 : Les Triggers (base HHB-Direct)
-- Aubrée Romain - SLAM Groupe 1 - 09/10/2026
-- Exercice d'application : numéro d'agence calculé automatiquement
-- ==========================================================

-- À l'insertion d'une nouvelle agence, l'utilisateur ne saisit que le nom et
-- l'adresse (et éventuellement le téléphone). Le numéro d'agence est calculé
-- automatiquement à partir du plus grand numéro déjà présent.
CREATE OR REPLACE FUNCTION Insert_agence() RETURNS trigger
LANGUAGE plpgsql
AS $function$
	begin
		if NEW.num_agence is null then
			select coalesce(max(num_agence), 0) + 1 into NEW.num_agence from agence ;
		end if ;
		return NEW ; -- trigger BEFORE : insertion avec le numéro calculé
	end ;
$function$ ;

-- Déclencheur BEFORE INSERT sur agence
DROP TRIGGER IF EXISTS Trig_insert_agence ON agence ;
CREATE TRIGGER Trig_insert_agence BEFORE INSERT
	ON agence FOR EACH ROW
	EXECUTE PROCEDURE Insert_agence() ;

-- --- Test ---
-- Numéros existants : 1, 2, 3  ->  la nouvelle agence prendra le numéro 4
-- insert into agence(nom_agence, adresse_agence, tel_agence)
--   values ('Brest', '10 Rue de Siam, 29200 BREST', '0298001122') ;
-- select num_agence, nom_agence, adresse_agence from agence order by num_agence ;
