<?php

declare(strict_types=1);

namespace TP2\PIERRE_FEUILLE_CISEAUX;

/**
 * Mission
 * Le système renvoie la liste des coups de ton adversaire sous la forme d’une chaîne de caractères.
 *
 * Ici, on ne rigole pas, ce n’est pas le premier à 3 qui gagne, il faut gagner tous les coups !
 *
 * Si ton adversaire fait Pierre, tu dois faire Feuille, s’il fait Feuille, tu dois faire Ciseaux, s’il fait Ciseaux, tu dois faire Pierre !
 *
 * Règles
 * Chaque coup est représenté par une lettre :
 *
 * Pierre : P
 * Feuille : F
 * Ciseaux : C
 * Par exemple, le système va renvoyer PFCP. 4 coups donc : Pierre, Feuille, Ciseaux, Pierre, il faudra donc retourner FCPF.
 */
final class PFCGame
{
	private const PIERRE = 'P';
	private const FEUILLE = 'F';
	private const CISEAUX = 'C';

	private const COUPS_GAGNANTS = [
		self::PIERRE => self::FEUILLE,
		self::FEUILLE => self::CISEAUX,
		self::CISEAUX => self::PIERRE,
	];

	private function play(string $play): string
	{
		if (!isset(self::COUPS_GAGNANTS[$play])) {
			throw new \InvalidArgumentException("Coup invalide : '$play' (P, F ou C attendu)");
		}

		return self::COUPS_GAGNANTS[$play];
	}

	public function party(string $plays): string
	{
		$response = '';
		$nbPlays = strlen($plays) - 1;

		for ($i = 0; $i <= $nbPlays; $i++) {
			$response .= $this->play($plays[$i]);
		}

		return $response;
	}
}
