<?php

use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;
use TP2\PIERRE_FEUILLE_CISEAUX\PFCGame;

final class Pierre_feuille_ciseauxTest extends TestCase
{
    private PFCGame $PFCGame;

    public function setUp(): void
    {
        parent::setUp();
        $this->PFCGame = new PFCGame;
    }

    private function play(string $coup): string
    {
        $methode = new ReflectionMethod(PFCGame::class, 'play');

        return $methode->invoke($this->PFCGame, $coup);
    }

    public function test_feuille_battue_par_ciseaux(): void
    {
        $this->assertEquals('C', $this->play('F'));
    }

    public function test_ciseaux_battus_par_pierre(): void
    {
        $this->assertEquals('P', $this->play('C'));
    }

    public function test_pierre_battue_par_feuille(): void
    {
        $this->assertEquals('F', $this->play('P'));
    }

    public function test_partie_3_coups(): void
    {
        $this->assertEquals('FCP', $this->PFCGame->party('PFC'));
    }

    public function test_play_chaine_vide(): void
    {
        $this->expectException(InvalidArgumentException::class);
        $this->play('');
    }

    public function test_play_autre_caractere(): void
    {
        $this->expectException(InvalidArgumentException::class);
        $this->play('X');
    }

    public function test_play_minuscule(): void
    {
        $this->expectException(InvalidArgumentException::class);
        $this->play('p');
    }

    public function test_partie_vide(): void
    {
        $this->assertEquals('', $this->PFCGame->party(''));
    }

    public function test_partie_avec_coup_invalide(): void
    {
        $this->expectException(InvalidArgumentException::class);
        $this->PFCGame->party('PFXC');
    }

    public static function parties(): array
    {
        return [
            '1 coup' => ['P', 'F'],
            '2 coups' => ['PF', 'FC'],
            '3 coups' => ['PFC', 'FCP'],
            '5 coups' => ['CCPFP', 'PPFCF'],
            '10 coups' => ['PFCPFCPFCP', 'FCPFCPFCPF'],
            '20 coups' => ['PPFFCCPFCPPFFCCPFCPF', 'FFCCPPFCPFFCCPPFCPFC'],
        ];
    }

    #[DataProvider('parties')]
    public function test_partie_plusieurs_coups(string $coups, string $attendu): void
    {
        $this->assertEquals($attendu, $this->PFCGame->party($coups));
    }
}
