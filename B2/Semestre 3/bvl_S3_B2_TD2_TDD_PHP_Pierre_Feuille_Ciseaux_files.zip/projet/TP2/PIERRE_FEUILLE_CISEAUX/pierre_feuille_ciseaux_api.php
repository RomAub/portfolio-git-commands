<?php

declare(strict_types=1);

require_once __DIR__ . '/../../bin/vendor/autoload.php';

use Engine\Game;
use TP2\PIERRE_FEUILLE_CISEAUX\PFCGame;

$game = new Game('PIERRE_FEUILLE_CISEAUX');

$coups = $game->input()['coups'];

// CODE DU tp ------------------
$output = (new PFCGame)->party($coups);



// REPONSE ----------------------------
$game->output(['data' => $output]);
