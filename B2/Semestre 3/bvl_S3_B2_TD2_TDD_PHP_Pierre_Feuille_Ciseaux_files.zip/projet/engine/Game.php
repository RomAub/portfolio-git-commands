<?php

declare(strict_types=1);

namespace Engine;

final class Game
{
    private const GAGNANT = ['P' => 'F', 'F' => 'C', 'C' => 'P'];

    private string $coups = '';

    public function __construct(private string $challenge, int $nbCoups = 20)
    {
        $lettres = array_keys(self::GAGNANT);
        for ($i = 0; $i < $nbCoups; $i++) {
            $this->coups .= $lettres[random_int(0, 2)];
        }
    }

    public function input(): array
    {
        return ['coups' => $this->coups];
    }

    public function output(array $reponse): void
    {
        $attendu = strtr($this->coups, self::GAGNANT);
        $donnee = (string) ($reponse['data'] ?? '');
        $ok = $donnee === $attendu;

        echo '<!DOCTYPE html><html lang="fr"><head><meta charset="UTF-8"><title>' . $this->challenge . '</title>';
        echo '<style>body{font-family:Roboto,Arial,sans-serif;margin:40px;color:#333}code{font-size:15px}
            .res{border-left:4px solid ' . ($ok ? '#3ecf8e' : '#e74c3c') . ';padding:6px 16px;font-style:italic;font-weight:bold;font-size:18px;color:#555}</style></head><body>';
        echo '<h2>Challenge ' . $this->challenge . ' <small style="font-weight:normal;color:#888">(simulation locale)</small></h2>';
        echo '<p>Coups de l\'adversaire : <code>' . $this->coups . '</code></p>';
        echo '<p>Ma réponse : <code>' . htmlspecialchars($donnee) . '</code></p>';
        echo '<p class="res">' . ($ok ? 'Félicitations ! Challenge réussi avec succès !' : 'Raté... la réponse attendue était ' . $attendu) . '</p>';
        echo '</body></html>';
    }
}
