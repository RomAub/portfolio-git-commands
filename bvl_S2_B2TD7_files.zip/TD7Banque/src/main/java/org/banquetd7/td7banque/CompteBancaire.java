package org.banquetd7.td7banque;

public abstract class CompteBancaire {
    private String numeroCompte;
    private double solde;
    private String devise;
    private Client titulaire;

    public CompteBancaire(String numeroCompte, double solde, String devise, Client titulaire) {
        this.numeroCompte = numeroCompte;
        this.solde = solde;
        this.devise = devise;
        this.titulaire = titulaire;
    }

    public String getnumeroCompte() { return numeroCompte; }
    public void setnumeroCompte(String numeroCompte) { this.numeroCompte = numeroCompte; }

    public double getSolde() { return solde; }
    public void setSolde(double solde) { this.solde = solde; }

    public String getDevise() { return devise; }
    public void setDevise(String devise) { this.devise = devise; }

    public Client getTitulaire() { return titulaire; }
    public void setTitulaire(Client titulaire) { this.titulaire = titulaire; }


    public void crediter(double montant) {
        if (montant <= 0) {
            System.out.println("Le montant doit être supérieur a 0.");
            return;
        }

        this.solde += montant;
    }

    public void debiter(double montant) {
        if (montant <= 0) {
            System.out.println("Le montant doit être supérieur a 0.");
            return;
        }
        this.solde -= montant;
    }

    public String decrire() {
        return "n°: " + this.numeroCompte + " - solde: " + this.solde + " " + this.devise;
    }

    @Override
    public String toString() {
        return this.decrire();
    }

}

