package org.banquetd7.td7banque;

public class CompteEpargne extends CompteBancaire {
    private double taux;

    public CompteEpargne(String numeroCompte, double solde, String devise, Client titulaire, double taux) {
        super(numeroCompte, solde, devise, titulaire);
        this.taux = taux;
    }
    public double getTaux() {
        return taux;
    }
    public void setTaux(double taux) {
        this.taux = taux;
    }

    @Override
    public String decrire() {
        return "Compte Epargne " + super.decrire() + " - taux = " + (int)(this.getTaux() * 100) + "%";
    }

    public void ajouterInteret() {
        if (this.getSolde() > 0) {
            double calculInteret = this.getSolde() * this.taux;
            this.crediter(calculInteret);
        }
    }

    @Override
    public void debiter(double montant) {
        if (montant > (this.getSolde() / 2)) {
            throw new IllegalArgumentException("Retrait limité à la moitié du solde.");
        }
        super.debiter(montant);
    }
}

