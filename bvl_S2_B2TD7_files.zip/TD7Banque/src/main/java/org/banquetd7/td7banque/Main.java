package org.banquetd7.td7banque;

import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {
        Client benjamin = new Client(
                "Gravouil", "Benjamin", 1, LocalDate.of(1977, 5, 2),
                "enseignant", "lycée Paul Lapie, 5 boulevard AB, 92400 COURBEVOIE",
                "01.01.01.01.01", "prof.gravouil@gmail.com");

        CompteCourant c1 = new CompteCourant("13245411324", 2548200, "€", benjamin, "000000000001", -1000);
        CompteEpargne c2 = new CompteEpargne("32544771289", 1000, "€", benjamin, 0.05);
        CompteCourant c3 = new CompteCourant("22544771289", -214, "€", benjamin, "000000000002", -50);

        benjamin.getComptes().add(c1);
        benjamin.getComptes().add(c2);
        benjamin.getComptes().add(c3);

        System.out.println("--- Affichage initial ---");
        benjamin.info_comptes();

        c3.crediter(100);

        System.out.println("\n--- Après crédit de 100€ sur le compte c3 ---");
        benjamin.info_comptes();

        System.out.println("\n--- Ajout d'intêret sur le compte c3 ---");
        c2.ajouterInteret();

        System.out.println("\n--- Après ajout des intérêts sur le compte épargne ---");
        benjamin.info_comptes();
    }


}

