package org.banquetd7.td7banque;

public class CompteCourant extends CompteBancaire {
    private String numCarte;
    private double decouvertMax;

    public CompteCourant(String numero, double solde, String devise, Client titulaire, String numCarte, double decouvertMax) {
        super(numero, solde, devise, titulaire);
        this.numCarte = numCarte;
        this.decouvertMax = decouvertMax;
    }

    public String getNumCarte() {
        return numCarte;
    }
    public void setNumCarte(String numCarte) {
        this.numCarte = numCarte;
    }

    public double getDecouvertMax() {
        return decouvertMax;
    }
    public void setDecouvertMax(double decouvertMax) {
        this.decouvertMax = decouvertMax;
    }

    @Override
    public void debiter(double montant) {
        if (this.getSolde() - montant >= this.decouvertMax) {
            super.debiter(montant);
        } else {
            throw new IllegalArgumentException("Découvert max (" + this.decouvertMax + "€) dépassé !");
        }
    }
}
