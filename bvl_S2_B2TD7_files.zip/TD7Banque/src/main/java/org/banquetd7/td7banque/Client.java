package org.banquetd7.td7banque;

import java.time.LocalDate;
import java.util.List;
import java.util.ArrayList;

public class Client {
    private String nom;
    private String prenom;
    private int genre;
    private LocalDate dateNaissance;
    private String categorieSocioPro;
    private String adresse;
    private String tel;
    private String email;

    private List<CompteBancaire> comptes;

    public Client(String nom, String prenom, int genre, LocalDate dateNaissance,
                  String categorieSocioPro, String adresse, String tel, String email) {
        this.nom = nom;
        this.prenom = prenom;
        this.genre = genre;
        this.dateNaissance = dateNaissance;
        this.categorieSocioPro = categorieSocioPro;
        this.adresse = adresse;
        this.tel = tel;
        this.email = email;
        this.comptes = new ArrayList<>();
    }

    public String getNom() { return nom; }
    public void setNom(String nom) { this.nom = nom; }

    public String getPrenom() { return prenom; }
    public void setPrenom(String prenom) { this.prenom = prenom; }

    public int getGenre() { return genre; }
    public void setGenre(int genre) { this.genre = genre; }

    public LocalDate getDateNaissance() { return dateNaissance; }
    public void setDateNaissance(LocalDate dateNaissance) { this.dateNaissance = dateNaissance; }

    public String getCategorieSocioPro() { return categorieSocioPro; }
    public void setCategorieSocioPro(String categorieSocioPro) { this.categorieSocioPro = categorieSocioPro; }

    public String getAdresse() { return adresse; }
    public void setAdresse(String adresse) { this.adresse = adresse; }

    public String getTel() { return tel; }
    public void setTel(String tel) { this.tel = tel; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public List<CompteBancaire> getComptes() { return comptes; }
    public void setComptes(List<CompteBancaire> comptes) { this.comptes = comptes; }

    public void info_comptes() {
        String civilite = (this.genre == 1) ? "M." : "Mme";

        System.out.println("Liste des comptes de " + civilite + " " + this.nom + " " + this.prenom);

        for (CompteBancaire compteActuel : this.comptes) {
            System.out.println(compteActuel.decrire());
        }
    }

    @Override
    public String toString() {
        return this.nom + " " + this.prenom;
    }
}

