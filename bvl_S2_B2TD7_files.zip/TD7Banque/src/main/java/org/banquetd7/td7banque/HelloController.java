package org.banquetd7.td7banque;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;

import java.time.LocalDate;
import java.util.ArrayList;

public class HelloController {

    // --- BASE DE DONNEES EN MEMOIRE (RAM) ---
    private ArrayList<Client> listeClients = new ArrayList<>();

    // --- IDENTIFIANTS DES PANNEAUX (NAVIGATION) ---
    @FXML private VBox paneMenu;
    @FXML private AnchorPane paneCreationClient;
    @FXML private AnchorPane paneGestionClient;
    @FXML private AnchorPane paneCreationCompte;
    @FXML private AnchorPane paneGestionCompte;

    // --- IDENTIFIANTS : CREATION CLIENT ---
    @FXML private TextField txtNomClient, txtPrenomClient, txtCategorieClient, txtAdresseClient, txtTelClient, txtEmailClient;
    @FXML private RadioButton radioHomme, radioFemme;
    @FXML private ToggleGroup groupeGenre;
    @FXML private DatePicker dpDateNaissance;
    @FXML private Label lblStatutCreationClient;

    // --- IDENTIFIANTS : GESTION CLIENT ---
    @FXML private ListView<Client> listClientsGestion;
    @FXML private TextField txtGestNom, txtGestPrenom, txtGestCategorie, txtGestAdresse, txtGestTelephone, txtGestEmail;
    @FXML private RadioButton radioGestHomme, radioGestFemme;
    @FXML private DatePicker dpGestDateNaissance;
    @FXML private Label lblStatutGestionClient;

    // --- IDENTIFIANTS : CREATION COMPTE ---
    @FXML private ComboBox<Client> cbClientsCreationCompte;
    @FXML private RadioButton radioCourant, radioEpargne;
    @FXML private ToggleGroup groupeTypeCompte;
    @FXML private TextField txtNumCompte, txtNumCB, txtDecouvertMax, txtTaux, txtSolde;
    @FXML private Label lblStatutCreationCompte;

    // --- IDENTIFIANTS : GESTION COMPTE ---
    @FXML private ComboBox<Client> cbClientsGestionCompte;
    @FXML private ListView<CompteBancaire> listComptesGestion;
    @FXML private TextField txtMontantOperation;
    @FXML private Label lblStatutOperation;


    @FXML
    public void initialize() {
        // 1. Initialisation du jeu d'essai métier
        Client benjamin = new Client(
                "Gravouil", "Benjamin", 1, LocalDate.of(1977, 5, 2),
                "enseignant", "lycée Paul Lapie, 5 boulevard AB, 92400 COURBEVOIE",
                "01.01.01.01.01", "prof.gravouil@gmail.com");

        CompteCourant c1 = new CompteCourant("13245411324", 2548200, "€", benjamin, "000000000001", -1000);
        CompteEpargne c2 = new CompteEpargne("32544771289", 1000, "€", benjamin, 0.05);
        CompteCourant c3 = new CompteCourant("22544771289", -214, "€", benjamin, "000000000002", -50);

        benjamin.getComptes().add(c1);
        benjamin.getComptes().add(c2);
        benjamin.getComptes().add(c3);

        listeClients.add(benjamin);

        // 2. Sécurité d'interface : Gestion dynamique des champs Compte Courant / Epargne
        if (groupeTypeCompte != null) {
            txtTaux.setDisable(true); // Par défaut (Courant sélectionné)
            groupeTypeCompte.selectedToggleProperty().addListener((obs, oldVal, newVal) -> {
                if (radioCourant.isSelected()) {
                    txtNumCB.setDisable(false);
                    txtDecouvertMax.setDisable(false);
                    txtTaux.setDisable(true);
                    txtTaux.clear();
                } else {
                    txtNumCB.setDisable(true);
                    txtNumCB.clear();
                    txtDecouvertMax.setDisable(true);
                    txtDecouvertMax.clear();
                    txtTaux.setDisable(false);
                }
            });
        }

        // 3. Écouteur : Chargement des données client lors du clic dans la liste (Gestion Client)
        if (listClientsGestion != null) {
            listClientsGestion.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, clientSelectionne) -> {
                if (clientSelectionne != null) {
                    txtGestNom.setText(clientSelectionne.getNom());
                    txtGestPrenom.setText(clientSelectionne.getPrenom());

                    if (clientSelectionne.getGenre() == 1) {
                        radioGestHomme.setSelected(true);
                    } else {
                        radioGestFemme.setSelected(true);
                    }

                    dpGestDateNaissance.setValue(clientSelectionne.getDateNaissance());
                    txtGestCategorie.setText(clientSelectionne.getCategorieSocioPro());
                    txtGestAdresse.setText(clientSelectionne.getAdresse());
                    txtGestTelephone.setText(clientSelectionne.getTel());
                    txtGestEmail.setText(clientSelectionne.getEmail());

                    lblStatutGestionClient.setText(""); // Reset du statut
                }
            });
        }

        // 4. Écouteur : Chargement des comptes lors de la sélection d'un client (Gestion Compte)
        if (cbClientsGestionCompte != null) {
            cbClientsGestionCompte.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, clientSelectionne) -> {
                if (clientSelectionne != null) {
                    listComptesGestion.getItems().setAll(clientSelectionne.getComptes());
                    lblStatutOperation.setText("");
                }
            });
        }
    }


    // ==========================================
    // LOGIQUE METIER : ACTIONS
    // ==========================================

    @FXML
    protected void onEnregistrerClientClick() {
        try {
            if (txtNomClient.getText().isEmpty() || txtPrenomClient.getText().isEmpty() || dpDateNaissance.getValue() == null) {
                lblStatutCreationClient.setText("Erreur : Nom, prénom et date requis.");
                lblStatutCreationClient.setTextFill(Color.RED);
                return;
            }

            int genre = radioHomme.isSelected() ? 1 : 2;
            Client nouveauClient = new Client(
                    txtNomClient.getText(), txtPrenomClient.getText(), genre, dpDateNaissance.getValue(),
                    txtCategorieClient.getText(), txtAdresseClient.getText(), txtTelClient.getText(), txtEmailClient.getText()
            );

            listeClients.add(nouveauClient);
            lblStatutCreationClient.setText("Succès : Client enregistré.");
            lblStatutCreationClient.setTextFill(Color.GREEN);

            txtNomClient.clear(); txtPrenomClient.clear(); txtCategorieClient.clear();
            txtAdresseClient.clear(); txtTelClient.clear(); txtEmailClient.clear();
            dpDateNaissance.setValue(null);

        } catch (Exception e) {
            lblStatutCreationClient.setText("Erreur technique lors de la création.");
            lblStatutCreationClient.setTextFill(Color.RED);
        }
    }

    @FXML
    protected void onMettreAJourClient() {
        Client clientSelectionne = listClientsGestion.getSelectionModel().getSelectedItem();

        if (clientSelectionne == null) {
            lblStatutGestionClient.setText("Erreur : Veuillez sélectionner un client.");
            lblStatutGestionClient.setTextFill(Color.RED);
            return;
        }

        // Mise à jour INTÉGRALE de l'objet métier
        clientSelectionne.setNom(txtGestNom.getText());
        clientSelectionne.setPrenom(txtGestPrenom.getText());
        clientSelectionne.setGenre(radioGestHomme.isSelected() ? 1 : 2);
        clientSelectionne.setDateNaissance(dpGestDateNaissance.getValue());
        clientSelectionne.setCategorieSocioPro(txtGestCategorie.getText());
        clientSelectionne.setAdresse(txtGestAdresse.getText());
        clientSelectionne.setTel(txtGestTelephone.getText());
        clientSelectionne.setEmail(txtGestEmail.getText());

        lblStatutGestionClient.setText("Succès : Profil mis à jour.");
        lblStatutGestionClient.setTextFill(Color.GREEN);
        listClientsGestion.refresh(); // Force la mise à jour visuelle de la liste
    }

    @FXML
    protected void onCreerCompteClick() {
        Client titulaire = cbClientsCreationCompte.getValue();
        if (titulaire == null) {
            lblStatutCreationCompte.setText("Erreur : Sélectionnez un titulaire.");
            lblStatutCreationCompte.setTextFill(Color.RED);
            return;
        }

        try {
            double soldeInitial = Double.parseDouble(txtSolde.getText());
            String numCompte = txtNumCompte.getText();
            if (numCompte.isEmpty()) throw new IllegalArgumentException("Numéro de compte vide.");

            CompteBancaire nouveauCompte;

            if (radioCourant.isSelected()) {
                double decouvert = Double.parseDouble(txtDecouvertMax.getText());
                String numCB = txtNumCB.getText();
                nouveauCompte = new CompteCourant(numCompte, soldeInitial, "€", titulaire, numCB, decouvert);
            } else {
                double taux = Double.parseDouble(txtTaux.getText());
                nouveauCompte = new CompteEpargne(numCompte, soldeInitial, "€", titulaire, taux);
            }

            titulaire.getComptes().add(nouveauCompte);
            lblStatutCreationCompte.setText("Succès : Compte créé et rattaché.");
            lblStatutCreationCompte.setTextFill(Color.GREEN);

        } catch (NumberFormatException e) {
            lblStatutCreationCompte.setText("Erreur : Solde, découvert ou taux invalide.");
            lblStatutCreationCompte.setTextFill(Color.RED);
        } catch (IllegalArgumentException e) {
            lblStatutCreationCompte.setText("Erreur : " + e.getMessage());
            lblStatutCreationCompte.setTextFill(Color.RED);
        }
    }

    @FXML
    protected void onCrediterClick() {
        executerOperation("credit");
    }

    @FXML
    protected void onDebiterClick() {
        executerOperation("debit");
    }

    private void executerOperation(String type) {
        CompteBancaire compte = listComptesGestion.getSelectionModel().getSelectedItem();
        if (compte == null) {
            lblStatutOperation.setText("Erreur : Sélectionnez un compte d'abord.");
            lblStatutOperation.setTextFill(Color.RED);
            return;
        }

        try {
            double montant = Double.parseDouble(txtMontantOperation.getText());
            if (montant <= 0) throw new NumberFormatException();

            if (type.equals("credit")) {
                compte.crediter(montant);
                lblStatutOperation.setText("Succès : Compte crédité de " + montant + " €.");
                lblStatutOperation.setTextFill(Color.GREEN);
            } else {
                compte.debiter(montant);
                lblStatutOperation.setText("Succès : Opération de débit effectuée.");
                lblStatutOperation.setTextFill(Color.GREEN);
            }

            listComptesGestion.refresh();
            txtMontantOperation.clear();

        } catch (NumberFormatException e) {
            lblStatutOperation.setText("Erreur : Montant invalide.");
            lblStatutOperation.setTextFill(Color.RED);
        } catch (IllegalArgumentException e) {
            // C'EST ICI QUE L'INTERFACE ATTRAPE LE REFUS DU COMPTE COURANT
            lblStatutOperation.setText("Opération refusée : " + e.getMessage());
            lblStatutOperation.setTextFill(Color.RED);
        }
    }

    @FXML
    protected void onAjouterInteretsClick() {
        CompteBancaire compte = listComptesGestion.getSelectionModel().getSelectedItem();
        if (compte == null) {
            lblStatutOperation.setText("Erreur : Sélectionnez un compte.");
            lblStatutOperation.setTextFill(Color.RED);
            return;
        }

        if (compte instanceof CompteEpargne) {
            ((CompteEpargne) compte).ajouterInteret();
            lblStatutOperation.setText("Succès : Intérêts ajoutés au compte.");
            lblStatutOperation.setTextFill(Color.GREEN);
            listComptesGestion.refresh();
        } else {
            lblStatutOperation.setText("Erreur : Ce n'est pas un compte épargne.");
            lblStatutOperation.setTextFill(Color.RED);
        }
    }


    // ==========================================
    // LOGIQUE DE NAVIGATION (AFFICHAGE DES VUES)
    // ==========================================

    private void masquerTout() {
        paneMenu.setVisible(false);
        paneCreationClient.setVisible(false);
        paneGestionClient.setVisible(false);
        paneCreationCompte.setVisible(false);
        paneGestionCompte.setVisible(false);
    }

    @FXML
    protected void retourMenu() {
        masquerTout();
        paneMenu.setVisible(true);
    }

    @FXML
    protected void onCreationClientClick() {
        masquerTout();
        paneCreationClient.setVisible(true);
        lblStatutCreationClient.setText("");
    }

    @FXML
    protected void onGestionClientClick() {
        masquerTout();
        paneGestionClient.setVisible(true);
        listClientsGestion.getItems().setAll(listeClients);
        lblStatutGestionClient.setText("");
    }

    @FXML
    protected void onCreationCompteClick() {
        masquerTout();
        paneCreationCompte.setVisible(true);
        cbClientsCreationCompte.getItems().setAll(listeClients);
        lblStatutCreationCompte.setText("");
    }

    @FXML
    protected void onGestionCompteClick() {
        masquerTout();
        paneGestionCompte.setVisible(true);
        cbClientsGestionCompte.getItems().setAll(listeClients);
        listComptesGestion.getItems().clear();
        lblStatutOperation.setText("");
    }
}