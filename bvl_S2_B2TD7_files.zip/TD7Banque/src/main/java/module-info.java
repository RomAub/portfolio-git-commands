module org.banquetd7.td7banque {
    requires javafx.controls;
    requires javafx.fxml;


    opens org.banquetd7.td7banque to javafx.fxml;
    exports org.banquetd7.td7banque;
}