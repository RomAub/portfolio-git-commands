<?php
session_start(); // démarrage d'une session
// on vérifie que les variables de session identifiant l'utilisateur existent
if (isset($_SESSION['nom']) && isset($_SESSION['prenom'])) {
    $nom = $_SESSION['nom'];
    $prenom = $_SESSION['prenom'];
}
?>
<!doctype html>
<html>
<head>
<meta charset="UTF-8" />
<title>Accueil du site</title>
</head>
<body>
<?php
require_once 'fonctions.php';

if (isset($nom) && isset($prenom)) {
    echo "<p>Bienvenue, " . escape($prenom) . " " . escape($nom) . ".</p>";
    echo "<h1>Accueil du site</h1>";
} else {  ?>
    <p>L'accès à cette page est réservé aux utilisateurs authentifiés</p>
    <p><a href="login.php">Se connecter</a></p>
<?php } ?>
</body>
</html>