<?php
session_start(); // démarrage d'une session
// on vérifie que les données du formulaire sont présentes

if (isset($_POST['login']) && isset($_POST['mdp'])) {
 require 'fonctions.php';
 $bdd = getBdd();
 
 // cette requête permet de récupérer l'utilisateur depuis la BD
    $login = $_POST['login'];
    $mdp = $_POST['mdp'];
    $requete = "SELECT * FROM utilis WHERE LoginUtil = ?";
    $resultat = $bdd->prepare($requete);
    $resultat->execute(array($login));
 
if ($resultat->rowCount() == 1) {
        $utilisateur = $resultat->fetch();
        
        if ($utilisateur['PassUtil'] == $mdp) {
            $_SESSION['login'] = $login;
            $_SESSION['nom'] = $utilisateur['NomUtil'];
            $_SESSION['prenom'] = $utilisateur['PrenomUtil'];
            
            $authOK = true;
        } else {
            $erreur = "Mot de passe incorrect.";
        }
    } else {
        $erreur = "Login inconnu.";
    }
}

?>
<!doctype html>
<html>
<head>
<meta charset="UTF-8" />
<title>Résultat de l'authentification</title>
</head>
<body>
<h1>Résultat de l'authentification</h1>
<?php
if (isset($authOK)) {
    echo "<p>Vous avez été reconnu(e) en tant que " . escape($login) . "</p>";
    echo '<a href="index.php">Poursuivre vers la page d\'accueil</a>';
}
else { 
    echo "<p>Vous n'avez pas été reconnu(e)</p>";
    if (isset($erreur)) {
        echo "<p style='color:red;'><strong>Erreur :</strong> " . escape($erreur) . "</p>";
    }
?>
    <p><a href="login.php">Nouvel essai</a></p>
<?php } ?>
</body>
</html>