-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : sam. 02 mai 2026 à 19:49
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `monsite`
--

-- --------------------------------------------------------

--
-- Structure de la table `utilis`
--

CREATE TABLE `utilis` (
  `NumUtil` int(11) NOT NULL,
  `NomUtil` varchar(30) NOT NULL,
  `PrenomUtil` varchar(30) NOT NULL,
  `LoginUtil` varchar(10) NOT NULL,
  `PassUtil` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `utilis`
--

INSERT INTO `utilis` (`NumUtil`, `NomUtil`, `PrenomUtil`, `LoginUtil`, `PassUtil`) VALUES
(1, 'Alizan', 'Gaspar', 'galiz', 'azerty'),
(2, 'Diossy', 'Daisy', 'ddios', '12345');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `utilis`
--
ALTER TABLE `utilis`
  ADD PRIMARY KEY (`NumUtil`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `utilis`
--
ALTER TABLE `utilis`
  MODIFY `NumUtil` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
